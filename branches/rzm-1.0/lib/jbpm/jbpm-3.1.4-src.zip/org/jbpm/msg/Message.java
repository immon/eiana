/*
 * JBoss, Home of Professional Open Source
 * Copyright 2005, JBoss Inc., and individual contributors as indicated
 * by the @authors tag. See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.jbpm.msg;

import java.io.Serializable;

import org.jbpm.JbpmException;
import org.jbpm.command.ExecuteActionCommand;
import org.jbpm.command.ExecuteNodeCommand;
import org.jbpm.graph.exe.Token;
import org.jbpm.util.EqualsUtil;

public abstract class Message implements Serializable {

  protected long id;
  protected String destination = null;
  protected String exception;
  protected Token token;
  protected boolean isSuspended = false;

  public Message() {
  }

  public static Message createCopy(Message message) {
    Message copy = null;
    if (message instanceof ExecuteNodeCommand) {
      copy = new ExecuteNodeCommand((ExecuteNodeCommand) message);
    } else if (message instanceof ExecuteActionCommand) {
      copy = new ExecuteActionCommand((ExecuteActionCommand) message);
    } else {
      throw new JbpmException("jBPM internal panic: can't create copy of message '"+message+"'");
    }
    return copy;
  }

  // equals ///////////////////////////////////////////////////////////////////
  // hack to support comparing hibernate proxies against the real objects
  // since this always falls back to ==, we don't need to overwrite the hashcode
  public boolean equals(Object o) {
    return EqualsUtil.equals(this, o);
  }
  
  // getters and setters //////////////////////////////////////////////////////

  public long getId() {
    return id;
  }
  public String getDestination() {
    return destination;
  }
  public void setDestination(String destination) {
    this.destination = destination;
  }
  public String getException() {
    return exception;
  }
  public void setException(String exception) {
    this.exception = exception;
  }
  public Token getToken() {
    return token;
  }
  public void setToken(Token token) {
    this.token = token;
  }
  public boolean isSuspended() {
    return isSuspended;
  }
  public void setSuspended(boolean isSuspended) {
    this.isSuspended = isSuspended;
  }
}
