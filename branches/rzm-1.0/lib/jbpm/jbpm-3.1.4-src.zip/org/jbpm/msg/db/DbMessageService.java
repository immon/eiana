/*
 * JBoss, Home of Professional Open Source
 * Copyright 2005, JBoss Inc., and individual contributors as indicated
 * by the @authors tag. See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.jbpm.msg.db;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jbpm.JbpmContext;
import org.jbpm.JbpmException;
import org.jbpm.db.MessagingSession;
import org.jbpm.graph.exe.Token;
import org.jbpm.msg.Message;
import org.jbpm.msg.MessageService;

public class DbMessageService implements MessageService {
  
  private static final long serialVersionUID = 1L;

  MessagingSession messagingSession = null;
  Collection destinations = null;
  
  public DbMessageService() {
    JbpmContext jbpmContext = JbpmContext.getCurrentJbpmContext();
    if (jbpmContext==null) {
      throw new JbpmException("instantiation of the DbMessageService requires a current JbpmContext");
    }
    this.messagingSession = jbpmContext.getMessagingSession();
  }

  public void send(Message message) {
    String destination = message.getDestination();
    if (destination==null) {
      throw new JbpmException("message without destination cannot be sent");
    }
    log.trace("sending msg '"+message+"' to destination '"+destination+"'");
    messagingSession.save(message);
    addDestination(destination);
  }

  public void suspendMessages(Token token) {
    messagingSession.suspendMessages(token);
  }

  public void resumeMessages(Token token) {
    messagingSession.resumeMessages(token);
  }

  public boolean hasMessages(String destination) {
    return messagingSession.hasNextMessage(destination);
  }

  public Message receiveNoWait(String destination) {
    Message message = messagingSession.nextMessage(destination);
    if (message!=null) {
      log.trace("received msg '"+message+"'");
      messagingSession.delete(message);
    }
    return message;
  }

  public Message receiveByIdNoWait(long id) {
    Message message = messagingSession.loadMessage(id);
    log.trace("received msg by id '"+id+"' :"+message);
    if (message!=null) {
      messagingSession.delete(message);
    }
    return message;
  }

  public MessagingSession getMessagingSession() {
    return messagingSession;
  }

  public void close() {
    // notify destinations
    if (destinations!=null) {
      Iterator iter = destinations.iterator();
      while (iter.hasNext()) {
        String destination = (String) iter.next();
        StaticNotifier.notify(destination);
      }
    }
  }
  
  void addDestination(String destination) {
    if (destinations==null) {
      destinations = new ArrayList();
    }
    destinations.add(destination);
  }

  private static Log log = LogFactory.getLog(DbMessageService.class);
}
