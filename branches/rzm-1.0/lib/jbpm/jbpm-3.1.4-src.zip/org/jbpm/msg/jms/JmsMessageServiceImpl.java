/*
 * JBoss, Home of Professional Open Source
 * Copyright 2005, JBoss Inc., and individual contributors as indicated
 * by the @authors tag. See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.jbpm.msg.jms;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.jbpm.JbpmException;
import org.jbpm.graph.exe.Token;
import org.jbpm.msg.Message;
import org.jbpm.msg.MessageService;

public class JmsMessageServiceImpl implements MessageService {

  private static final long serialVersionUID = 1L;
  
  Connection connection = null;
  Session session = null;
  Destination destination = null;
  MessageProducer messageProducer = null;
  boolean isCommitEnabled = true;
  
  public JmsMessageServiceImpl(Connection connection, Session session, Destination destination, boolean isCommitEnabled) {
    this.connection = connection;
    this.session = session;
    this.destination = destination;
    this.isCommitEnabled = isCommitEnabled; 
  }

  public void send(Message message) {
    try {
      ObjectMessage objectMessage = session.createObjectMessage(message);
      Token token = message.getToken();
      if (token!=null) {
        objectMessage.setLongProperty("tokenId", token.getId());
      }
      getMessageProducer().send(destination, objectMessage);
    } catch (JMSException e) {
      throw new JbpmException("couldn't send jms message", e);
    }
  }

  public void close() {
    Throwable exception = null;
    try {
      if (messageProducer!=null) messageProducer.close();
    } catch (Exception e) {
      // NOTE that Error's are not caught because that might halt the JVM and mask the original Error.
      exception = e;
    }
    try {
      if ( (session!=null)
           && (isCommitEnabled)
         ) {
        session.commit();
      }
    } catch (Exception e) {
      if (exception!=null) {
        exception = new JbpmException("couldn't commit JMS session", e);
      } else {
        exception = e;
      }
    }
    try {
      if (session!=null) session.close();
    } catch (Exception e) {
      if (exception!=null) {
        exception = new JbpmException("couldn't close JMS session", e);
      } else {
        exception = e;
      }
    }
    try {
      if (connection!=null) connection.close();
    } catch (Exception e) {
      if (exception!=null) {
        exception = new JbpmException("couldn't close JMS connection", e);
      } else {
        exception = e;
      }
    }
    
    if (exception!=null) {
      throw new JbpmException("couldn't close one of the jms objects", exception);
    }
  }

  public void suspendMessages(Token token) {
    // TODO move the messages for the given token to the suspended queue
    // might also be enough to update a message property on those messages.
  }

  public void resumeMessages(Token token) {
    // TODO move the messages for the given token to the suspended queue
    // might also be enough to update a message property on those messages.
  }

  MessageProducer getMessageProducer() throws JMSException {
    if (messageProducer==null) {
      messageProducer = session.createProducer(destination);
    }
    return messageProducer;
  }

  public boolean hasMessages() {
    return false;
  }

  public Message receiveNoWait() {
    return null;
  }

  public Message receiveByIdNoWait(long id) {
    return null;
  }
}
