/*
 * JBoss, Home of Professional Open Source
 * Copyright 2005, JBoss Inc., and individual contributors as indicated
 * by the @authors tag. See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.jbpm.db;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.jbpm.JbpmException;
import org.jbpm.graph.exe.Token;
import org.jbpm.msg.Message;

public class MessagingSession implements Serializable {

  private static final long serialVersionUID = 1L;

  Session session = null;
  List openIterators = null;
  Message nextMessage = null;

  public MessagingSession(Session session) {
    this.session = session;
  }

  public void save(Message message) {
    session.saveOrUpdate(message);
  }
  
  public void delete(Message message) {
    session.delete(message);
  }

  public boolean hasNextMessage(String destination) {
    Iterator messageIterator = getMessageIterator(destination);
    boolean hasMessages = messageIterator.hasNext();
    if (hasMessages) {
      nextMessage = (Message) messageIterator.next();
    }
    return hasMessages;
  }

  public Message nextMessage(String destination) {
    Message message = null;
    if (nextMessage!=null) {
      message = nextMessage;
      nextMessage = null;
    } else {
      Iterator messageIterator = getMessageIterator(destination);
      if (messageIterator.hasNext()) {
        message = (Message) messageIterator.next();
      }
      if (messageIterator.hasNext()) {
        nextMessage = (Message) messageIterator.next();
      }
    }
    return message;
  }

  public void closeOpenIterators() {
    if (openIterators!=null) {
      for(Iterator iterIter = openIterators.iterator(); iterIter.hasNext(); ) {
        Iterator messageIterator = (Iterator) iterIter.next();
        Hibernate.close(messageIterator);
      }
    }
  }

  public Message loadMessage(long id) {
    return (Message) session.load(Message.class, new Long(id));
  }

  public Message getMessage(long id) {
    return (Message) session.get(Message.class, new Long(id));
  }

  public List findMessages(String destination) {
    List messages = null;
    Query query = session.getNamedQuery("MessagingSession.findMessages");
    query.setString("destination", destination);
    messages = query.list();
    return messages;
  }

  public List findErrorMessages(String destination) {
    List messages = null;
    Query query = session.getNamedQuery("MessagingSession.findErrorMessages");
    query.setString("destination", destination);
    messages = query.list();
    return messages;
  }

  public Iterator getMessageIterator(String destination) {
    if (destination==null) throw new JbpmException("destination is null");
    Query query = session.getNamedQuery("MessagingSession.findMessages");
    query.setString("destination", destination);
    Iterator iterator = query.iterate();
    if (openIterators==null) {
      openIterators = new ArrayList();
      openIterators.add(iterator);
    }
    return iterator;
  }
  
  public void suspendMessages(Token token) {
    Query query = session.getNamedQuery("MessagingSession.suspendMessagesForToken");
    query.setEntity("token", token);
    query.executeUpdate();
  }

  public void resumeMessages(Token token) {
    Query query = session.getNamedQuery("MessagingSession.resumeMessagesForToken");
    query.setEntity("token", token);
    query.executeUpdate();
  }
}
