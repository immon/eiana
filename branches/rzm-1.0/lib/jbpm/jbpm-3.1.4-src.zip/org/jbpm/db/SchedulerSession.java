/*
 * JBoss, Home of Professional Open Source
 * Copyright 2005, JBoss Inc., and individual contributors as indicated
 * by the @authors tag. See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.jbpm.db;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.jbpm.JbpmException;
import org.jbpm.graph.def.Action;
import org.jbpm.graph.exe.ProcessInstance;
import org.jbpm.graph.exe.Token;
import org.jbpm.scheduler.exe.Timer;

public class SchedulerSession {

  JbpmSession jbpmSession = null;
  Session session = null;
  Set deletedTimers = new HashSet();
  List openIterators = null;
  
  public SchedulerSession(JbpmSession jbpmSession) {
    this.jbpmSession = jbpmSession;
    this.session = jbpmSession.getSession();
  }

  public SchedulerSession(Session session) {
    this.session = session;
    this.jbpmSession = new JbpmSession(session);
  }

  public void saveTimer(Timer timer) {
    try {
      log.debug("saving timer");
      session.save(timer);
      Action action = timer.getAction();
      if ( (action!=null) 
           && (! session.contains(action))
         ) {
        log.debug("cascading timer save to timer action");
        session.save(action);
      }
    } catch (Exception e) {
      log.error(e);
      jbpmSession.handleException();
      throw new JbpmException("couldn't save timer '"+timer+"' to the database", e);
    }
  }

  public void deleteTimer(Timer timer) {
    if (! deletedTimers.contains(timer)) {
      try {
        session.delete(timer);
        deletedTimers.add(timer);
      } catch (Exception e) {
        log.error(e);
        jbpmSession.handleException();
        throw new JbpmException("couldn't delete timer '"+timer+"' from the database", e);
      }
    }
  }

  public Iterator findTimersByDueDate(int maxResultCount) {
    try {
      Query query = session.getNamedQuery("SchedulerSession.findTimersByDueDate");
      query.setMaxResults(maxResultCount);
      Iterator iterator = query.iterate();
      addOpenIterator(iterator);
      return iterator;
    } catch (Exception e) {
      log.error(e);
      jbpmSession.handleException();
      throw new JbpmException("couldn't find timers from the database", e);
    }
  }

  public Iterator findFailedTimers() {
    try {
      Iterator iterator = session.getNamedQuery("SchedulerSession.findFailedTimers").iterate();
      addOpenIterator(iterator);
      return iterator;
    } catch (Exception e) {
      log.error(e);
      jbpmSession.handleException();
      throw new JbpmException("couldn't find failed timers from the database", e);
    }
  }

  public Iterator findSuspendedTimers() {
    try {
      Iterator iterator = session.getNamedQuery("SchedulerSession.findSuspendedTimers").iterate();
      addOpenIterator(iterator);
      return iterator;
    } catch (Exception e) {
      log.error(e);
      jbpmSession.handleException();
      throw new JbpmException("couldn't find failed timers from the database", e);
    }
  }
  
  private void addOpenIterator(Iterator iterator) {
    if (openIterators==null) {
      openIterators = new ArrayList();
    }
    openIterators.add(iterator);
  }

  public void closeOpenIterators() {
    if (openIterators!=null) {
      for(Iterator iterIter = openIterators.iterator(); iterIter.hasNext(); ) {
        Iterator messageIterator = (Iterator) iterIter.next();
        Hibernate.close(messageIterator);
      }
    }
  }

  public void cancelTimersByName(String timerName, Token token) {
    try {
      Query query = session.getNamedQuery("SchedulerSession.findTimersByName");
      query.setString("timerName", timerName);
      query.setEntity("token", token);
      Iterator iter = query.list().iterator();
      while(iter.hasNext()) {
        deleteTimer((Timer) iter.next());
      }
      
    } catch (Exception e) {
      log.error(e);
      jbpmSession.handleException();
      throw new JbpmException("couldn't delete timer '"+timerName+"' on '"+token+"' from the database", e);
    }
  }

  public List findTimersByName(String timerName, Token token) {
    List results = null;
    try {
      Query query = session.getNamedQuery("SchedulerSession.findTimersByName");
      query.setString("timerName", timerName);
      query.setEntity("token", token);
      results = query.list();
      
    } catch (Exception e) {
      log.error(e);
      jbpmSession.handleException();
      throw new JbpmException("couldn't find timers '"+timerName+"' in '"+token+"' from the database", e);
    }
    return results;
  }

  public void cancelTimersForProcessInstance(ProcessInstance processInstance) {
    try {
      Query query = session.getNamedQuery("SchedulerSession.deleteTimersForProcessInstance");
      query.setEntity("processInstance", processInstance);
      query.executeUpdate();
      
    } catch (Exception e) {
      log.error(e);
      jbpmSession.handleException();
      throw new JbpmException("couldn't delete timers for process instance '"+processInstance+"'", e);
    }
  }
  
  public void suspendTimersForProcessInstance(Token token) {
    try {
      Query query = session.getNamedQuery("SchedulerSession.suspendTimersForToken");
      query.setEntity("token", token);
      query.executeUpdate();
      
    } catch (Exception e) {
      log.error(e);
      jbpmSession.handleException();
      throw new JbpmException("couldn't delete timers for token '"+token+"'", e);
    }
  }

  public void resumeTimersForProcessInstance(Token token) {
    try {
      Query query = session.getNamedQuery("SchedulerSession.resumeTimersForToken");
      query.setEntity("token", token);
      query.executeUpdate();
      
    } catch (Exception e) {
      log.error(e);
      jbpmSession.handleException();
      throw new JbpmException("couldn't delete timers for token '"+token+"'", e);
    }
  }

  private static final Log log = LogFactory.getLog(SchedulerSession.class);
}
