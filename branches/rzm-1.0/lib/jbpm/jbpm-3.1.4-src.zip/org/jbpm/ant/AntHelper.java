/*
 * JBoss, Home of Professional Open Source
 * Copyright 2005, JBoss Inc., and individual contributors as indicated
 * by the @authors tag. See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.jbpm.ant;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.cfg.Configuration;
import org.jbpm.JbpmConfiguration;
import org.jbpm.JbpmException;
import org.jbpm.persistence.db.DbPersistenceServiceFactory;
import org.jbpm.svc.Services;

/**
 * common strategy for jbpm ant tasks to obtain a hibernate SessionFactory.
 */
public abstract class AntHelper {
  
  final static Map configurations = new HashMap();
  final static Map jbpmConfigurations = new HashMap();

  public static Configuration getConfiguration(String cfgFileName, String propertiesFileName) {
    Object key = getKey(cfgFileName,propertiesFileName);
    Configuration configuration = (Configuration) configurations.get(key);
    if (configuration==null) {
      log.debug("creating hibernate configuration from cfg '"+cfgFileName+"' and properties '"+propertiesFileName+"'");
      File cfgFile = new File(cfgFileName);
      configuration = new Configuration();
      configuration.configure(cfgFile);
      if (propertiesFileName!=null) {
        try {
          File propertiesFile = new File(propertiesFileName);
          FileInputStream propertiesInputStream = new FileInputStream(propertiesFile);
          Properties properties = new Properties();
          properties.load(propertiesInputStream);
          configuration.setProperties(properties);
        } catch (Exception e) {
          throw new JbpmException("couldn't set properties '"+propertiesFileName+"'", e);
        }
      }
      configurations.put(key, configuration);
    } else {
      log.debug("got hibernate configuration from cfg '"+cfgFileName+"' and properties '"+propertiesFileName+"' from the cache");
    }
    return configuration;
  }

  public static JbpmConfiguration getJbpmConfiguration(String cfg, String properties) {
    Object key = getKey(cfg,properties);
    JbpmConfiguration jbpmConfiguration = (JbpmConfiguration) jbpmConfigurations.get(key);
    if (jbpmConfiguration==null) {
      jbpmConfiguration = JbpmConfiguration.parseXmlString(
        "<jbpm-configuration>" +
        " <jbpm-context>" +
        "  <service name='persistence' factory='org.jbpm.persistence.db.DbPersistenceServiceFactory' />" +
        " </jbpm-context>" +
        " <string name='resource.business.calendar' value='org/jbpm/calendar/jbpm.business.calendar.properties' />" +
        " <string name='resource.default.modules' value='org/jbpm/graph/def/jbpm.default.modules.properties' />" +
        " <string name='resource.converter' value='org/jbpm/db/hibernate/jbpm.converter.properties' />" +
        " <string name='resource.action.types' value='org/jbpm/graph/action/action.types.xml' />" +
        " <string name='resource.node.types' value='org/jbpm/graph/node/node.types.xml' />" +
        " <string name='resource.parsers' value='org/jbpm/jpdl/par/jbpm.parsers.xml' />" +
        " <string name='resource.varmapping' value='org/jbpm/context/exe/jbpm.varmapping.xml' />" +
        "</jbpm-configuration>"
      );

      Configuration configuration = getConfiguration(cfg, properties);
      DbPersistenceServiceFactory dbPersistenceServiceFactory = (DbPersistenceServiceFactory) jbpmConfiguration.getServiceFactory(Services.SERVICENAME_PERSISTENCE);
      dbPersistenceServiceFactory.setConfiguration(configuration);

      jbpmConfigurations.put(key, jbpmConfiguration);
    }
    return jbpmConfiguration;
  }

  static Object getKey(String cfg, String properties) {
    List key = new ArrayList();
    key.add(cfg);
    key.add(properties);
    return key;
  }

  private static final Log log = LogFactory.getLog(AntHelper.class);
}
