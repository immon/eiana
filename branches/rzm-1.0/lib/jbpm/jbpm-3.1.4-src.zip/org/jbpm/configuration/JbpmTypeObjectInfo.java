/*
 * JBoss, Home of Professional Open Source
 * Copyright 2005, JBoss Inc., and individual contributors as indicated
 * by the @authors tag. See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.jbpm.configuration;

import org.jbpm.context.exe.Converter;
import org.jbpm.context.exe.JbpmType;
import org.jbpm.context.exe.JbpmTypeMatcher;
import org.jbpm.context.exe.VariableInstance;
import org.jbpm.db.hibernate.Converters;
import org.jbpm.util.ClassLoaderUtil;
import org.jbpm.util.XmlUtil;
import org.w3c.dom.Element;

public class JbpmTypeObjectInfo extends AbstractObjectInfo {

  private static final long serialVersionUID = 1L;
  
  ObjectInfo typeMatcherObjectInfo = null;
  Converter converter = null;
  Class variableInstanceClass = null;
  
  public JbpmTypeObjectInfo(Element jbpmTypeElement, ObjectFactoryParser objectFactoryParser) {
    super(jbpmTypeElement, objectFactoryParser);
  
    Element typeMatcherElement = XmlUtil.element(jbpmTypeElement, "matcher");
    if (typeMatcherElement==null) {
      throw new ConfigurationException("matcher is a required element in a jbpm-type: "+XmlUtil.toString(jbpmTypeElement));
    }
    Element typeMatcherBeanElement = XmlUtil.element(typeMatcherElement);
    typeMatcherObjectInfo = objectFactoryParser.parse(typeMatcherBeanElement);
    
    Element converterElement = XmlUtil.element(jbpmTypeElement, "converter");
    if (converterElement!=null) {
      if (! converterElement.hasAttribute("class")) {
        throw new ConfigurationException("class attribute is required in a converter element: "+XmlUtil.toString(jbpmTypeElement));
      }
      String converterClassName = converterElement.getAttribute("class");
      converter = Converters.getConverterByClassName(converterClassName);
    }
    
    Element variableInstanceElement = XmlUtil.element(jbpmTypeElement, "variable-instance");
    if (! variableInstanceElement.hasAttribute("class")) {
      throw new ConfigurationException("class is a required attribute in element variable-instance: "+XmlUtil.toString(jbpmTypeElement));
    }
    String variableInstanceClassName = variableInstanceElement.getAttribute("class");
    try {
      variableInstanceClass = ClassLoaderUtil.loadClass(variableInstanceClassName);
      if (! VariableInstance.class.isAssignableFrom(variableInstanceClass)) {
        throw new ConfigurationException("variable instance class '"+variableInstanceClassName+"' is not a VariableInstance");
      }
    } catch (Exception e){
      variableInstanceClass = null;
      throw new ConfigurationException("invalid variable instance class name '"+variableInstanceClassName+"' : "+XmlUtil.toString(jbpmTypeElement));
    }
  }

  public Object createObject(ObjectFactoryImpl objectFactory) {
    JbpmTypeMatcher jbpmTypeMatcher = (JbpmTypeMatcher) objectFactory.createObject(typeMatcherObjectInfo);
    return new JbpmType(jbpmTypeMatcher, converter, variableInstanceClass);
  }
}
