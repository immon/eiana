/*
 * JBoss, Home of Professional Open Source
 * Copyright 2005, JBoss Inc., and individual contributors as indicated
 * by the @authors tag. See the copyright.txt in the distribution for a
 * full listing of individual contributors.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.jbpm.command;

import org.jbpm.JbpmException;
import org.jbpm.graph.def.Action;
import org.jbpm.graph.exe.ExecutionContext;
import org.jbpm.graph.exe.Token;
import org.jbpm.msg.Message;

public class ExecuteActionCommand extends Message implements Command {

  private static final long serialVersionUID = 1L;
  
  Action action = null;

  public ExecuteActionCommand() {
  }
  
  public ExecuteActionCommand(Action action, Token token) {
    this.action = action;
    this.token = token;
    this.destination = DEFAULT_CMD_DESTINATION; 
  }

  public ExecuteActionCommand(ExecuteActionCommand other) {
    this.action = other.action;
    this.token = other.token;
    this.destination = other.destination; 
  }

  public void execute() {
    try {
      ExecutionContext executionContext = new ExecutionContext(token);
      action.execute(executionContext );
    } catch (Exception e) {
      throw new JbpmException("couldn't execute '"+action+"' on '"+token+"'", e);
    }
  }
}
