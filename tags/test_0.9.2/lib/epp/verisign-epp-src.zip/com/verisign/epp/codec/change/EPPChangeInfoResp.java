/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.verisign.epp.codec.change.type.EPPChangeAction;
import com.verisign.epp.codec.change.util.ExceptionUtil;
import com.verisign.epp.codec.change.util.TextUtil;
import com.verisign.epp.codec.change.util.TypeUtil;
import com.verisign.epp.codec.gen.EPPCodec;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPResponse;
import com.verisign.epp.codec.gen.EPPTransId;
import com.verisign.epp.codec.gen.EPPUtil;
import com.verisign.epp.util.EqualityUtil;

/**
 * An <code>EPPChangeInfoResp</code> provides an answer to an
 * <code>EPPChangeInfoCmd</code> and includes the following attributes:<br>
 * <br>
 * <ul>
 * <li>A &lt;change:requestID&gt; element that contains the Request Id. Use
 * <code>getRequest</code> and <code>setRequest</code> to get and set the
 * element.</li>
 * <li>A &lt;change:priority&gt; element that contains the Request Priority.
 * Use <code>getPriority</code> and <code>setPriority</code> to get and set
 * the element.</li>
 * <li>A &lt;change:category&gt; element that contains the Request Category.
 * Use <code>getCategory</code> and <code>setCategory</code> to get and set
 * the element.</li>
 * <li>A &lt;desc&gt; element that contains the Request Description. Use
 * <code>getDescription</code> and <code>setDescription</code> to get and
 * set the element.</li>
 * <li>A &lt;status&gt; element that contains the Request Status. Use
 * <code>getStatus</code> and <code>setStatus</code> to get and set the
 * element.</li>
 * <li>A &lt;crDate&gt; element that contains the Request Created Date. Use
 * <code>getCreatedDate</code> and <code>setCreatedDate</code> to get and
 * set the element.</li>
 * <li>A &lt;upDate&gt; element that contains the Request Updated Date. Use
 * <code>getUpdatedDate</code> and <code>setUpdatedDate</code> to get and
 * set the element.</li>
 * <li>A &lt;crID&gt; element that contains the Request Created Id. Use
 * <code>getCreatedId</code> and <code>setCreatedId</code> to get and set
 * the element.</li>
 * <li>A &lt;upID&gt; element that contains the Request Updated Id. Use
 * <code>getUpdatedId</code> and <code>setUpdatedId</code> to get and set
 * the element.</li>
 * <li>0 or more &lt;action&gt; elements that represent Change Actions. Use
 * <code>addAction</code>, <code>clearActions</code>,
 * <code>getActions</code>, and <code>setActions</code> to manipulate these
 * elements.</li>
 * </ul>
 * <br>
 * @see EPPChangeInfoCmd
 * @author jcolosi
 */
public class EPPChangeInfoResp extends EPPResponse {
	final static String ELM_NAME = "change:infData";

	private String requestId = null;
	private String priority = null;
	private List categories = null;
	private String description = null;
	private String status = null;
	private Date createdDate = null;
	private Date updatedDate = null;
	private String createdId = null;
	private String updatedId = null;
	private List actions = null;

	/**
	 * Default constructor that needs the <code>key</code> attribute and the
	 * transid attribute set prior to calling <code>encode</code>.
	 */
	public EPPChangeInfoResp() {}

	/**
	 * Creates an <code>EPPChangeInfoResp</code> only the transaction id set.
	 * The <code>key</code> attribute must be set prior to calling
	 * <code>encode</code>.
	 * @param aTransId The transaction id containing the server transaction and
	 *            optionally the client transaction id
	 */
	public EPPChangeInfoResp(EPPTransId aTransId) {
		super(aTransId);
	}

	public void addAction(EPPChangeAction action) {
		if (actions == null) actions = new ArrayList();
		if (action != null) actions.add(action);
	}

	public void addCategory(String category) {
		if (categories == null) categories = new ArrayList();
		if (category != null) categories.add(TextUtil.normalize(category));
	}

	public void clearActions() {
		this.actions = null;
	}

	public void clearCategories() {
		this.categories = null;
	}

	/**
	 * Does a deep clone of the <code>EPPChangeInfoResp</code> instance.
	 * @return Cloned instance
	 */
	public Object clone() throws CloneNotSupportedException {
		return (EPPChangeInfoResp) super.clone();
	}

	/**
	 * Compare an instance of <code>EPPChangeInfoResp</code> with this
	 * instance
	 */
	public boolean equals(Object o) {
		if ((o == null) || (!o.getClass().equals(this.getClass()))) return false;
		EPPChangeInfoResp other = (EPPChangeInfoResp) o;

		return EqualityUtil.equals(this.requestId, other.requestId)
				&& EqualityUtil.equals(this.priority, other.priority)
				&& EqualityUtil.equals(this.categories, other.categories)
				&& EqualityUtil.equals(this.requestId, other.requestId)
				&& EqualityUtil.equals(this.description, other.description)
				&& EqualityUtil.equals(this.status, other.status)
				&& EqualityUtil.equals(this.createdDate, other.createdDate)
				&& EqualityUtil.equals(this.updatedDate, other.updatedDate)
				&& EqualityUtil.equals(this.createdId, other.createdId)
				&& EqualityUtil.equals(this.updatedId, other.updatedId)
				&& EqualityUtil.equals(this.actions, other.actions);
	}

	public List getActions() {
		return actions;
	}

	public List getCategories() {
		return categories;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public String getCreatedDateString() {
		return TextUtil.encodeDate(createdDate);
	}

	public String getCreatedId() {
		return createdId;
	}

	public String getDescription() {
		return description;
	}

	/**
	 * Gets the EPP command namespace associated with
	 * <code>EPPChangeInfoResp</code>.
	 * @return <code>EPPChangeMapFactory.NS</code>
	 */
	public String getNamespace() {
		return EPPChangeMapFactory.NS;
	}

	public String getPriority() {
		return priority;
	}

	public String getRequestId() {
		return requestId;
	}

	public String getStatus() {
		return status;
	}

	/**
	 * Gets the EPP response type associated with <code>EPPChangeInfoResp</code>.
	 * @return <code>EPPChangeInfoResp.ELM_NAME</code>
	 */
	public String getType() {
		return ELM_NAME;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public String getUpdatedDateString() {
		return TextUtil.encodeDate(updatedDate);
	}

	public String getUpdatedId() {
		return updatedId;
	}

	public void setActions(List actions) {
		this.actions = actions;
	}

	public void setCategories(List categories) {
		this.categories = categories;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = TextUtil.normalize(createdDate);
	}

	public void setCreatedDate(String createdDate) throws ParseException {
		this.createdDate = TextUtil.decodeDate(createdDate);
	}

	public void setCreatedId(String createdId) {
		this.createdId = TextUtil.normalize(createdId);
	}

	public void setDescription(String description) {
		this.description = TextUtil.normalize(description);
	}

	public void setPriority(String priority) {
		this.priority = TextUtil.normalize(priority);
	}

	public void setRequestId(String requestId) {
		this.requestId = TextUtil.normalize(requestId);
	}

	public void setStatus(String status) {
		this.status = TextUtil.normalize(status);
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = TextUtil.normalize(updatedDate);
	}

	public void setUpdatedDate(String updatedDate) throws ParseException {
		this.updatedDate = TextUtil.decodeDate(updatedDate);
	}

	public void setUpdatedId(String updatedId) {
		this.updatedId = TextUtil.normalize(updatedId);
	}

	/**
	 * Implementation of <code>Object.toString</code>, which will result in
	 * an indented XML <code>String</code> representation of the concrete
	 * <code>EPPCodecComponent</code>.
	 * @return Indented XML <code>String</code> if successful;
	 *         <code>ERROR</code> otherwise.
	 */
	public String toString() {
		return EPPUtil.toString(this);
	}

	/**
	 * Decode the <code>EPPChangeInfoResp</code> attributes from the aElement
	 * DOM Element tree.
	 * @param aElement Root DOM Element to decode <code>EPPChangeInfoResp</code>
	 *            from.
	 * @exception EPPDecodeException Unable to decode aElement
	 */
	protected void doDecode(Element aElement) throws EPPDecodeException {
		try {
			/**
			 * LOGIC: Decode nested elements
			 */
			NodeList nodes = aElement.getChildNodes();
			if (nodes != null) {
				int size = nodes.getLength();
				for (int i = 0; i < size; i++) {
					Node node = nodes.item(i);
					if (node instanceof Element) {
						String name = node.getNodeName();
						if (name.equals(TypeUtil.ELM_REQUESTID)) setRequestId(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_PRIORITY)) setPriority(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_CATEGORY)) addCategory(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_DESCRIPTION)) setDescription(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_STATUS)) setStatus(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_CREATED_DATE)) setCreatedDate(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_UPDATED_DATE)) setUpdatedDate(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_CREATED_ID)) setCreatedId(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_UPDATED_ID)) setUpdatedId(EPPUtil
								.getTextContent(node));
						else if (name.equals(EPPChangeAction.ELM_NAME)) addAction(new EPPChangeAction(
								(Element) node));
					}
				}
			}
		} catch (ParseException x) {
			throw new EPPDecodeException(x.getMessage());
		}

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForDecode(requestId, TypeUtil.ELM_REQUESTID);
		ExceptionUtil.assertForDecode(priority, TypeUtil.ELM_PRIORITY);
		ExceptionUtil.assertForDecode(categories, TypeUtil.ELM_CATEGORY);
		ExceptionUtil.assertForDecode(description, TypeUtil.ELM_DESCRIPTION);
		ExceptionUtil.assertForDecode(status, TypeUtil.ELM_STATUS);
		ExceptionUtil.assertForDecode(createdDate, TypeUtil.ELM_CREATED_DATE);
		ExceptionUtil.assertForDecode(updatedDate, TypeUtil.ELM_UPDATED_DATE);
		ExceptionUtil.assertForDecode(createdId, TypeUtil.ELM_CREATED_ID);
		ExceptionUtil.assertForDecode(updatedId, TypeUtil.ELM_UPDATED_ID);
	}

	/**
	 * Encode a DOM Element tree from the attributes of the
	 * <code>EPPChangeInfoResp</code> instance.
	 * @param aDocument DOM Document that is being built. Used as an Element
	 *            factory.
	 * @return Root DOM Element representing the <code>EPPChangeInfoResp</code>
	 *         instance.
	 * @exception EPPEncodeException Unable to encode
	 *                <code>EPPChangeInfoResp</code> instance.
	 */
	protected Element doEncode(Document aDocument) throws EPPEncodeException {
		Element root = aDocument.createElementNS(EPPChangeMapFactory.NS, ELM_NAME);
		root.setAttribute("xmlns:change", EPPChangeMapFactory.NS);
		root.setAttributeNS(EPPCodec.NS_XSI, "xsi:schemaLocation",
				EPPChangeMapFactory.NS_SCHEMA);

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForEncode(requestId, TypeUtil.ELM_REQUESTID);
		ExceptionUtil.assertForEncode(priority, TypeUtil.ELM_PRIORITY);
		ExceptionUtil.assertForEncode(categories, TypeUtil.ELM_CATEGORY);
		ExceptionUtil.assertForEncode(description, TypeUtil.ELM_DESCRIPTION);
		ExceptionUtil.assertForEncode(status, TypeUtil.ELM_STATUS);
		ExceptionUtil.assertForEncode(createdDate, TypeUtil.ELM_CREATED_DATE);
		ExceptionUtil.assertForEncode(updatedDate, TypeUtil.ELM_UPDATED_DATE);
		ExceptionUtil.assertForEncode(createdId, TypeUtil.ELM_CREATED_ID);
		ExceptionUtil.assertForEncode(updatedId, TypeUtil.ELM_UPDATED_ID);

		EPPUtil.encodeString(aDocument, root, requestId, EPPChangeMapFactory.NS,
				TypeUtil.ELM_REQUESTID);
		EPPUtil.encodeString(aDocument, root, priority, EPPChangeMapFactory.NS,
				TypeUtil.ELM_PRIORITY);
		EPPUtil.encodeList(aDocument, root, categories, EPPChangeMapFactory.NS,
				TypeUtil.ELM_CATEGORY);
		EPPUtil.encodeString(aDocument, root, description, EPPChangeMapFactory.NS,
				TypeUtil.ELM_DESCRIPTION);
		EPPUtil.encodeString(aDocument, root, status, EPPChangeMapFactory.NS,
				TypeUtil.ELM_STATUS);
		TextUtil.encodeDate(aDocument, root, createdDate, EPPChangeMapFactory.NS,
				TypeUtil.ELM_CREATED_DATE);
		TextUtil.encodeDate(aDocument, root, updatedDate, EPPChangeMapFactory.NS,
				TypeUtil.ELM_UPDATED_DATE);
		EPPUtil.encodeString(aDocument, root, createdId, EPPChangeMapFactory.NS,
				TypeUtil.ELM_CREATED_ID);
		EPPUtil.encodeString(aDocument, root, updatedId, EPPChangeMapFactory.NS,
				TypeUtil.ELM_UPDATED_ID);
		EPPUtil.encodeCompList(aDocument, root, actions);

		return root;
	}

}
