/***********************************************************
Copyright (C) 2004 VeriSign, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

http://www.verisign.com/nds/naming/namestore/techdocs.html
***********************************************************/
package com.verisign.epp.util;


// Log4j Imports
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.verisign.epp.exception.*;
import com.verisign.epp.util.EPPCatFactory;


/**
 * <p>
 * Title:
 * </p>
 * 
 * <p>
 * Description:
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2002
 * </p>
 * 
 * <p>
 * Company:
 * </p>
 *
 * @author Colin W. Lloyd
 * @version 1.0
 */
public class HttpXMLErrorHandler implements ErrorHandler {
	/** Log4j category for logging */
	private static Logger cat =
		Logger.getLogger(
						 HttpXMLErrorHandler.class.getName(),
						 EPPCatFactory.getInstance().getFactory());

	/**
	 * Creates a new HttpXMLErrorHandler object.
	 */
	public HttpXMLErrorHandler() {
	}

	/**
	 * Receive notification of a recoverable error. This method will first log
	 * the message and later it will throw the SAXEception.
	 *
	 * @param newException which is a SAXParseException
	 *
	 * @exception SAXException According to the W3C Recommendation this is
	 * 			  called if there is a violation in the rules of the
	 * 			  specifiaction. ie the document was not valid
	 * @throws EPPXMLErrorHandlerErrorException DOCUMENT ME!
	 */
	public void error(SAXParseException newException) throws SAXException {
		cat.error(
				  "EPP XML Error : " + getErrorString(newException) + " : "
				  + newException.getMessage(), newException);

		throw new EPPXMLErrorHandlerErrorException(
												   "EPPXMLErrorHandler.error() : "
												   + getErrorString(newException)
												   + " : "
												   + newException.getMessage(),
												   newException);
	}

	/**
	 * Receive notification of a non-recoverable error. This method will first
	 * log the message and later it will throw the SAXEception.
	 *
	 * @param newException which is a SAXParseException
	 *
	 * @exception SAXException This is called if the document wasn't well
	 * 			  formed.
	 * @throws EPPXMLErrorHandlerFatalException DOCUMENT ME!
	 */
	public void fatalError(SAXParseException newException)
					throws SAXException {
		cat.error(
				  "EPP XML Fatal Error : " + getErrorString(newException)
				  + " : " + newException.getMessage(), newException);

		throw new EPPXMLErrorHandlerFatalException(
												   "EPPXMLErrorHandler.fatalError() : "
												   + getErrorString(newException)
												   + " : "
												   + newException.getMessage(),
												   newException);
	}

	/**
	 * Receive notification of a warning. This method will first log the
	 * message and later it will throw the SAXEception.
	 *
	 * @param newException which is a SAXParseException
	 *
	 * @exception SAXException
	 * @throws EPPXMLErrorHandlerWarningException DOCUMENT ME!
	 */
	public void warning(SAXParseException newException)
				 throws SAXException {
		cat.error(
				  "EPP XML Warining : " + getErrorString(newException) + " : "
				  + newException.getMessage(), newException);

		throw new EPPXMLErrorHandlerWarningException(
													 "EPPXMLErrorHandler.fatalError() : "
													 + getErrorString(newException)
													 + " : "
													 + newException.getMessage(),
													 newException);
	}

	/**
	 * Returns a more descriptive Error Message.
	 *
	 * @param newException which is a SAXParseException
	 *
	 * @return DOCUMENT ME!
	 */
	private String getErrorString(SAXParseException newException) {
		StringBuffer myStringBuffer = new StringBuffer();

		String		 systemId = newException.getSystemId();

		if (systemId != null) {
			int index = systemId.lastIndexOf('/');

			if (index != -1) {
				systemId = systemId.substring(index + 1);
			}

			myStringBuffer.append(systemId);
		}

		return myStringBuffer.toString() + "\nLine....: "
			   + newException.getLineNumber() + "\nColumn..: "
			   + newException.getColumnNumber() + "\nMessage.:";
	}
}
