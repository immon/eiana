/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.rootzone.util;

/**
 * This class holds constants for use with the RootZone implementation of the
 * Change mapping. Specifically, these constants can be used in conjunction with
 * the Status field of a RootZone Change Request. However, the client should not
 * need to set the Status attribute.
 * @author jcolosi
 */
public abstract class RootZoneStatus {

	/** Initial status for a Change Request */
	static public final String INITIAL = "initial";

	/**
	 * Submitted by IANA for review and execution static public final String
	 */
	static public final String SUBMITTED = "submitted";

	/**
	 * Submitted Change Request has timed out waiting on DoC approval
	 */
	static public final String DOC_APPROVAL_TIMEOUT = "docApprovalTimeout";

	/**
	 * Submitted Change Request was rejected by DoC
	 */
	static public final String DOC_REJECTED = "docRejected";

	/**
	 * Change Request failed automated validation
	 */
	static public final String VALIDATION_ERROR = "validationError";

	/**
	 * Change Request included warnings during automated validation and is put
	 * on Hold pending manual review
	 */
	static public final String HOLD = "hold";

	/**
	 * Change Request passed the automated validation
	 */
	static public final String SYSTEM_VALIDATED = "systemValidated";

	/**
	 * Network Services (NS) manually rejected a Change Request that had
	 * automated validation warnings
	 */
	static public final String NS_REJECTED = "nsRejected";

	/**
	 * Submitted Change Requet has received Doc approval
	 */
	static public final String DOC_APPROVED = "docApproved";

	/**
	 * Network Services has verified (automated and optionally manually) the
	 * Change Request and will implement it.
	 */
	static public final String NS_VERIFIED = "nsVerified";

	/**
	 * Change Request being executed against the RZMS Database and Zone being
	 * Generated
	 */
	static public final String DB_UPDATED = "dbUpdated";

	/**
	 * Zone Generation process failed
	 */
	static public final String ZONEGEN_FAILURE = "zonegenFailure";

	/**
	 * Zone successfully generated for Change Request
	 */
	static public final String GENERATED = "generated";

	/**
	 * Generated Zone failed test against local name server
	 */
	static public final String ZONE_VALIDATION_FAILED = "zoneValidationFailed";

	/**
	 * Generated Zone passed test against local name server
	 */
	static public final String LOCALLY_TESTED = "locallyTested";

	/**
	 * Zone has been pushed to the stealth masters
	 */
	static public final String PUSHED = "pushed";

	/**
	 * Zone failed push to the stealth masters
	 */
	static public final String PUSH_FAILURE = "pushFailure";

	/**
	 * Test for Change Request against A.root failed
	 */
	static public final String A_ROOT_TEST_FAILURE = "aRootTestFailure";

	/**
	 * Test for Change Request against A.root passed
	 */
	static public final String A_ROOT_TESTED = "aRootTested";

	/**
	 * Change Request succesfully executed
	 */
	static public final String COMPLETE = "complete";

}
