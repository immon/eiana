/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change;

import org.w3c.dom.Element;

import com.verisign.epp.codec.gen.EPPCodecException;
import com.verisign.epp.codec.gen.EPPCommand;
import com.verisign.epp.codec.gen.EPPMapFactory;
import com.verisign.epp.codec.gen.EPPResponse;
import com.verisign.epp.codec.gen.EPPService;

/**
 * <code>EPPChangeMapFactory</code> represents the <code>EPPCommand</code>
 * and <code>EPPResponseMap</code> factory for the EPP Change Mapping with the
 * XML Namespace URI "urn:ietf:params:xmlns:change". The fully qualified class
 * name for <code>EPPChangeMapFactory</code> is included in a call to
 * <code>EPPFactory.init</code> or <code>EPPCodec.init</code>.<br>
 * <br>
 * @author $Author: jim $
 * @version $Revision: 1.1.1.1 $
 * @see com.verisign.epp.codec.gen.EPPCodec
 * @see com.verisign.epp.codec.gen.EPPFactory
 * @see com.verisign.epp.codec.gen.EPPCommand
 * @see com.verisign.epp.codec.gen.EPPResponse
 */
public class EPPChangeMapFactory extends EPPMapFactory {
	/** Namespace URI associated with EPPChangeMapFactory. */
	public static final String NS = "http://www.verisign-grs.com/epp/change-1.0";

	/** Namespace prefix associated with EPPChangeMapFactory. */
	public static final String NS_PREFIX = "change";

	/** EPP Change XML Schema. */
	public static final String NS_SCHEMA = "http://www.verisign-grs.com/epp/change-1.0 change-1.0.xsd";

	/** Service description for <code>EPPChangeMapFactory</code> */
	private EPPService service = null;

	/**
	 * Allocates a new <code>EPPChangeMapFactory</code>. The service
	 * attribute will be initialized with the XML namespace information defined
	 * by the <code>EPPChangeMapFactory</code> constants: <br>
	 * <ul>
	 * <li>NS_PREFIX Namespace prefix of <code>EPPChangeMapFactory</code>
	 * </li>
	 * <li>NS Namespace URI of <code>EPPChangeMapFactory</code></li>
	 * <li>NS_SCHEMA Namespace schema reference of
	 * <code>EPPChangeMapFactory</code></li>
	 * </ul>
	 */
	public EPPChangeMapFactory() {
		service = new EPPService(NS_PREFIX, NS, NS_SCHEMA);
		service.setServiceType(0);
	}

	/**
	 * Creates a concrete <code>EPPCommand</code> from the passed in XML
	 * Element tree. <code>aMapElement</code> must be the root node for the
	 * command extension.
	 * @param aMapElement Mapping Extension EPP XML Element.
	 * @return Concrete <code>EPPCommand</code> instance associated with
	 *         <code>aMapElement</code>.
	 * @exception EPPCodecException Error creating concrete
	 *                <code>EPPCommand</code>
	 */
	public EPPCommand createCommand(Element aMapElement) throws EPPCodecException {
		String name = aMapElement.getTagName();

		if (name.equals(EPPChangeCheckCmd.ELM_NAME)) return new EPPChangeCheckCmd();
		else if (name.equals(EPPChangeInfoCmd.ELM_NAME)) return new EPPChangeInfoCmd();
		else if (name.equals(EPPChangeCreateCmd.ELM_NAME)) return new EPPChangeCreateCmd();
		else if (name.equals(EPPChangeUpdateCmd.ELM_NAME)) return new EPPChangeUpdateCmd();
		else if (name.equals(EPPChangeDeleteCmd.ELM_NAME)) return new EPPChangeDeleteCmd();
		else throw new EPPCodecException("Invalid command type " + name);
	}

	/**
	 * Creates a concrete <code>EPPResponse</code> from the passed in XML
	 * Element tree. <code>aMapElement</code> must be the root node for the
	 * command extension.
	 * @param aMapElement Mapping Extension EPP XML Element.
	 * @return Concrete <code>EPPResponse</code> instance associated with
	 *         <code>aMapElement</code>.
	 * @exception EPPCodecException Error creating concrete
	 *                <code>EPPResponse</code>
	 */
	public EPPResponse createResponse(Element aMapElement) throws EPPCodecException {
		String name = aMapElement.getTagName();

		if (name.equals(EPPChangeInfoResp.ELM_NAME)) return new EPPChangeInfoResp();
		else if (name.equals(EPPChangeCheckResp.ELM_NAME)) return new EPPChangeCheckResp();
		else if (name.equals(EPPChangeUpdateResp.ELM_NAME)) return new EPPChangeUpdateResp();
		else throw new EPPCodecException("Invalid command type " + name);
	}

	/**
	 * Gets the <code>EPPService</code> associated with
	 * <code>EPPChangeMapFactory</code>. The <code>EPPService</code> is
	 * used by <code>EPPFactory</code> for distributing the responsibility of
	 * creating concrete <code>EPPCommand</code> and <code>EPPResponse</code>
	 * objects by XML namespace. The XML namespace is defined in the returned
	 * <code>EPPService</code>.
	 * @return service description for the Change Command Mapping.
	 */
	public EPPService getService() {
		return service;
	}

}
