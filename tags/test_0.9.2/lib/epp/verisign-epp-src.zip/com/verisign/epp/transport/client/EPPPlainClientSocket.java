/***********************************************************
Copyright (C) 2004 VeriSign, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

http://www.verisign.com/nds/naming/namestore/techdocs.html
***********************************************************/
package com.verisign.epp.transport.client;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.UnknownHostException;

import org.apache.log4j.Logger;

import com.verisign.epp.transport.EPPClientCon;
import com.verisign.epp.transport.EPPConException;
import com.verisign.epp.util.EPPCatFactory;
import com.verisign.epp.util.EPPEnv;
import com.verisign.epp.util.EPPEnvException;


/**
 * This is a EPPPlainSocket Implementation
 *
 * @author P. Amiri
 * @version 1.0, 03/10/01
 *
 * @since JDK1.0
 */
public class EPPPlainClientSocket implements EPPClientCon {
	/** Log4j category for logging */
	private static Logger cat =
		Logger.getLogger(
						 EPPPlainClientSocket.class.getName(),
						 EPPCatFactory.getInstance().getFactory());

	/** This attibute maintains an instance of a Socket connection. */
	private Socket mySocket = null;

	/** This attribute contains OutputStream associated with the Socket. */
	private OutputStream myOutputStream = null;

	/** This attribute contains OutputStream associated with the Socket. */
	private InputStream myInputStream = null;

	/** This attribute contains Host Name */
	private String myHostName = null;

	/** This attribute contains port number */
	private int myPortNumber = 0;

	/** This attribute contains Client Host Name */
	private String myClientHostName = null;

	/** This attribute simple maintains Connection Status */
	private boolean isConnected = false;

	/** DOCUMENT ME! */
	private int myConTimeout = 5000;

	/**
	 * Pre-condition the util.Env provide the properties
	 *
	 * @exception EPPConException
	 */
	public EPPPlainClientSocket() throws EPPConException {
		try {
			myHostName		 = EPPEnv.getServerName();
			myPortNumber     = EPPEnv.getServerPort();
			myConTimeout     = EPPEnv.getConTimeOut();
			myClientHostName = EPPEnv.getClientHost();
		}
		 catch (EPPEnvException myException) {
			throw new EPPConException("Connection Failed Due to : "
									  + myException.getMessage());
		}
	}

	/**
	 * Initializes a TCP connection to the host and port defined by the 
	 * server name and the server port properties of <code>EPPEnv</code>.
	 *
	 * @exception EPPConException Error initializing the connection.
	 */
	public void initialize() throws EPPConException {
		try {
			if (this.myClientHostName == null) {
				cat.debug("EPPPlainClientSocket.initialize(): Connecting to server host = " + 
						myHostName + ", server port = " + myPortNumber);
				mySocket = new Socket(myHostName, myPortNumber);				
			}
			else {
				cat.debug("EPPPlainClientSocket.initialize(): Connecting to server host = " + 
						myHostName + ", server port = " + myPortNumber + 
						" from client host = " + myClientHostName);
				mySocket = new Socket();
				SocketAddress theClientAddress = new InetSocketAddress(this.myClientHostName, 0);
				SocketAddress theServerAddress = new InetSocketAddress(this.myHostName, this.myPortNumber);
				mySocket.bind(theClientAddress);
				mySocket.connect(theServerAddress);
			}
			mySocket.setSoTimeout(myConTimeout);
		}
		 catch (UnknownHostException myException) {
			cat.error(
					  "IP address of the host could not be determined. ",
					  myException);

			throw new EPPConException("IP address of the host could not be determined. "
									  + myException.getMessage());
		}
		 catch (IOException myException) {
			/**
			 * Log the Error
			 */
			cat.error(
					  "an I/O error occurs when creating the socket. ",
					  myException);

			throw new EPPConException("an I/O error occurs when creating the socket. "
									  + myException.getMessage());
		}
		 catch (SecurityException myException) {
			/**
			 * Log the Error
			 */
			cat.error(
					  "a security manager exists and its checkConnect "
					  + "method doesn't allow the operation. ", myException);

			throw new EPPConException("a security manager exists and its checkConnect "
									  + "method doesn't allow the operation. "
									  + myException.getMessage());
		}

		try {
			myInputStream	   = mySocket.getInputStream();
			myOutputStream     = mySocket.getOutputStream();
		}
		 catch (IOException myException) {
			/**
			 * Log the Error
			 */
			cat.error(
					  "An I/O Error Occured when creating Input Output Stream",
					  myException);

			throw new EPPConException("An I/O Error Occured when creating Input Output Stream"
									  + myException.getMessage());
		}
	}
	
	

	/**
	 * Initializes a TCP connection to a specific host and port.  There remainder of the 
	 * connection settings is derived from the <code>EPPEnv</code> properties.
	 * 
	 * @param aHostName Host name or IP address of host to connect to
	 * @param aPortNumber Port number to connect to
	 * @param aClientHostName Host name or IP address to connect from
	 * @param aSSLContext This should be <code>null</code> since this is a TCP connection
	 * 
	 * @exception EPPConException Error initializing the connection.
	 */
	public void initialize(String aHostName, int aPortNumber, String aClientHostName, EPPSSLContext aSSLContext)
			throws EPPConException {
		// Pre-condition check
		if (aSSLContext != null) {
			throw new EPPConException("aSSLContext is NOT null for a TCP socket");
		}
		
		this.myHostName = aHostName;
		this.myPortNumber = aPortNumber;
		this.myClientHostName = aClientHostName;
		
		this.initialize();
	}
		
	/**
	 * Initializes a TCP connection to a specific host and port and a 
	 * specific client host/IP address and client port number.  There remainder of the 
	 * connection settings is derived from the <code>EPPEnv</code> properties.
	 * 
	 * @param aHostName Host name or IP address of host to connect to
	 * @param aPortNumber Port number to connect to
	 * @param aSSLContext This should be <code>null</code> since this is a TCP connection
	 * 
	 * @exception EPPConException Error initializing the connection.
	 */
	public void initialize(String aHostName, int aPortNumber, EPPSSLContext aSSLContext)
			throws EPPConException {
		// Pre-condition check
		if (aSSLContext != null) {
			throw new EPPConException("aSSLContext is NOT null for a TCP socket");
		}
		
		this.myHostName = aHostName;
		this.myPortNumber = aPortNumber;
		
		this.initialize();
	}
		
	
	/**
	 * This method returns the InpuStream from established connection.
	 *
	 * @return InputStream
	 *
	 * @exception EPPConException
	 */
	public InputStream getInputStream() throws EPPConException {
		if (myInputStream == null) {
			throw new EPPConException("The Connection is properly initialized");
		}

		return myInputStream;
	}

	/**
	 * This is an Access method which returns and OutputStream from the
	 * established connection.
	 *
	 * @return OutputStream
	 *
	 * @exception EPPConException
	 */
	public OutputStream getOutputStream() throws EPPConException {
		if (myOutputStream == null) {
			throw new EPPConException("The Connection is properly initialized");
		}

		return myOutputStream;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param newInputStream
	 */
	public void setInputStream(InputStream newInputStream) {
		myInputStream = newInputStream;

		return;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param newOutputStream
	 */
	public void setOutputStream(OutputStream newOutputStream) {
		myOutputStream = newOutputStream;

		return;
	}

	/**
	 * Access method for the mySocket property.
	 *
	 * @return the current value of the mySocket property
	 */
	public Socket getSocket() {
		return mySocket;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param newSocket the new value of the mySocket property
	 */
	public void setSocket(Socket newSocket) {
		mySocket = newSocket;

		return;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @throws EPPConException DOCUMENT ME!
	 */
	public void close() throws EPPConException {
		if (!isConnected) {
			return;
		}

		/*
		 * Check to see if the connection
		 * is valid
		 */
		try {
			if (myOutputStream != null) {
				myOutputStream.close();
				myOutputStream = null;
			}

			if (myInputStream != null) {
				myInputStream.close();
				myInputStream = null;
			}
		}
		 catch (IOException myException) {
			throw new EPPConException("When Closing Conection : "
									  + myException.getMessage());
		}
		 catch (SecurityException myException) {
			// ignore this one
		}
		 finally {
			isConnected = false;
		}

		return;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param newHostName DOCUMENT ME!
	 */
	public void setHostName(String newHostName) {
		myHostName = newHostName;

		return;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param newPortNumber DOCUMENT ME!
	 */
	public void setPort(int newPortNumber) {
		myPortNumber = newPortNumber;

		return;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public String getHost() {
		return myHostName;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public int getPort() {
		return myPortNumber;
	}
}
