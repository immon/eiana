/***********************************************************
Copyright (C) 2004 VeriSign, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

http://www.verisign.com/nds/naming/namestore/techdocs.html
***********************************************************/
package com.verisign.epp.framework;


// PoolMan Imports
import com.codestudio.util.*;

// Log4j Imports
import org.apache.log4j.Logger;

// JAXP, SAX, DOM, and Xerces Imports
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;

// W3C imports
import org.w3c.dom.Document;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;

// Java imports
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;

// Javax HTTP Servlet imports
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

// Verisign imports
import com.verisign.epp.codec.gen.EPPCodec;
import com.verisign.epp.codec.gen.EPPCodecException;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPMessage;
import com.verisign.epp.exception.*;
import com.verisign.epp.serverstub.SessionData;
import com.verisign.epp.util.*;


/**
 * <p>
 * Title:
 * </p>
 * 
 * <p>
 * Description:
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2002
 * </p>
 * 
 * <p>
 * Company:
 * </p>
 *
 * @author Colin W. Lloyd
 * @version 1.0
 */
public class HttpEPPXMLAssembler implements EPPAssembler {
	/** Document Builder Factory for creating a parser per operation. */
	private static DocumentBuilderFactory factory = null;

	static {
		// Initialize the Document Builder Factory
		factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		factory.setValidating(true);
	}

	/** DOCUMENT ME! */
	private static boolean _parserInitialized = false;

	/** Log4j category for logging */
	private static Logger cat =
		Logger.getLogger(
						 HttpEPPXMLAssembler.class.getName(),
						 EPPCatFactory.getInstance().getFactory());

	/** GenericPoolManager for releasing object back to pool */
	private GenericPoolManager manager;

	/** Name of pool to use with the pool manager (manager). */
	private String poolName;

	/**
	 * An EPPCodec is delegated to to do the real work.
	 * <code>HttpEPPXMLAssembler</code> just wraps it to provide the
	 * EPPAssembler interface.
	 */
	private EPPCodec codec;

	/**
	 * Construct and instance of an <code>HttpEPPXMLAssembler</code>
	 */
	public HttpEPPXMLAssembler() {
		codec     = EPPCodec.getInstance();

		/**
		 * Use EPPXMLParser.POOL by default
		 */
		poolName = EPPSchemaCachingParser.POOL;
		initParserPool();
	}

	/**
	 * Construct and instance of an <code>HttpEPPXMLAssembler</code>
	 *
	 * @param parserPoolName DOCUMENT ME!
	 */
	public HttpEPPXMLAssembler(String parserPoolName) {
		codec     = EPPCodec.getInstance();

		poolName = parserPoolName;
		initParserPool();
	}

	/**
	 * Takes an <code>EPPEventResponse </code> and serializes it to an
	 * <code>OutputStream</code> in XML Format. Also gets the current servlet
	 * response and populates the appropriate http headers
	 *
	 * @param aResponse The response that will be serialized
	 * @param aOutputStream The OutputStream that the response will be
	 * 		  serialized to.
	 * @param aData DOCUMENT ME!
	 *
	 * @exception EPPAssemblerException Error serializing the
	 * 			  <code>EPPEventResponse</code>
	 */
	public void toStream(
						 EPPEventResponse aResponse, OutputStream aOutputStream,
						 Object aData) throws EPPAssemblerException {
		cat.debug("toStream(EPPEventResponse, OutputStream): Enter");

		try {
			/**
			 * First, get the message and convert it to a DOM Document using
			 * the codec
			 */
			EPPMessage response    = aResponse.getResponse();
			Document   domDocument = codec.encode(response);

			/**
			 * Replaced the 2 calls below with their implementation code so
			 * that we can also get the content length and set it in the
			 * response.
			 */

			//            GlnEPPXMLStream xmlStream = new GlnEPPXMLStream();
			//            xmlStream.write(domDocument, aOutputStream);
			// Validate arguments
			if (aOutputStream == null) {
				cat.error("write(Document, InputStream): aOutput == null");
				throw new EPPException("EPPXMLStream.write() : BAD ARGUMENT (aOutput)");
			}

			ByteArrayOutputStream theBuffer = new ByteArrayOutputStream();

			// Serialize DOM Document to stream
			try {
				XMLSerializer theSerializer =
					new XMLSerializer(theBuffer, (OutputFormat) null);

				theSerializer.serialize(domDocument);

				theBuffer.close();
			}
			 catch (IOException ex) {
				cat.error(
						  "write(Document, InputStream) : serialize() :"
						  + ex.getMessage(), ex);
				throw new EPPException("EPPXMLStream.write : serialize() "
									   + ex.getMessage());
			}

			cat.debug("HttpEPPXMLAssembler.write() : Sending [" + theBuffer
					  + "]");

			// Write to stream
			try {
				byte[] writingBytes = theBuffer.toByteArray();
				int    byteLength = writingBytes.length;

				/**
				 * set the http header in the http response from the servlet
				 * context
				 */
				SessionData		    sessionData = (SessionData) aData;
				HttpServletResponse httpResp =
					(HttpServletResponse) sessionData.getAttribute("servletResponse");

				httpResp.setContentLength(byteLength);
				httpResp.setContentType("text/xml");

				aOutputStream.write(theBuffer.toByteArray());
				aOutputStream.flush();
			}
			 catch (IOException ex) {
				cat.error("write(Document, InputStream) : Writing to stream :"
						  + ex);
				throw new EPPException("EPPXMLStream.write() : Writing to stream "
									   + ex);
			}

			/**
			 * end of replacement
			 */
		}
		 catch (EPPEncodeException e) {
			cat.error("toStream(EPPEventResponse, OutputStream)", e);
			e.printStackTrace();

			if (e.equals(EPPCodecException.MISSINGPARAMETER)) {
				cat.debug("EPPEncodeException with "
						  + "EPPCodecException.MISSINGPARAMETER caught, "
						  + "sending EPPAssemblerException.MISSINGPARAMETER");

				throw new EPPAssemblerException(
												e.getMessage(),
												EPPAssemblerException.MISSINGPARAMETER);
			}
			else {
				cat.debug("EPPEncodeException caught, sending"
						  + " EPPAssemblerException.XML");
				throw new EPPAssemblerException(
												e.getMessage(),
												EPPAssemblerException.XML);
			}
		}
		 catch (EPPException e) {
			cat.error("toStream(EPPEventResponse, OutputStream)", e);
			e.printStackTrace();
			throw new EPPAssemblerException(
											e.getMessage(),
											EPPAssemblerException.FATAL);
		}

		cat.debug("toStream(EPPEventResponse, OutputStream): Return");
	}

	/**
	 * Takes an <code>InputStream</code> and reads XML from it to create an
	 * <code>EPPEvent</code>
	 *
	 * @param aStream The InputStream to read data from.
	 * @param aData DOCUMENT ME!
	 *
	 * @return EPPEvent The <code> EPPEvent </code> that is created from the
	 * 		   InputStream
	 *
	 * @exception EPPAssemblerException Error creating the
	 * 			  <code>EPPEvent</code>
	 */
	public EPPEvent toEvent(InputStream aStream, Object aData)
					 throws EPPAssemblerException {
		cat.debug("toEvent(InputStream): Enter");

		EPPMessage message = null;

		/**
		 * Take an XML input stream and convert it to a DOM Document
		 */
		try {
			//            cat.debug("Instantiating xmlStream and getting parser from pool...")

			/** Declare an instance of the EPPXMLStream class */

			//            EPPXMLStream xmlStream =
			//                    new EPPXMLStream(EPPXMLParser.POOL);

			/**
			 * Take the DOM Document and convert it to an EPPMessage using the
			 * EPPCodec
			 */
			Document domDocument = this.readPacket(aStream, aData);
			message = codec.decode(domDocument);
		}

		/**
		 * EPPDecodeException comes from the codec...
		 */
		 catch (EPPDecodeException e) {
			cat.error("toEvent(InputStream):", e);
			e.printStackTrace();

			if (e.equals(EPPCodecException.MISSINGPARAMETER)) {
				cat.debug("EPPDecodeException with"
						  + "EPPCodecException.MISSINGPARAMETER caught, "
						  + "sending EPPAssemblerException.MISSINGPARAMETER");

				throw new EPPAssemblerException(
												e.getMessage(),
												EPPAssemblerException.MISSINGPARAMETER);
			}
			else {
				cat.debug("EPPDecodeException caught, sending"
						  + " EPPAssemblerException.XML");
				throw new EPPAssemblerException(
												e.getMessage(),
												EPPAssemblerException.XML);
			}
		}

		/**
		 * Explicitly rethrow the assembler exception...
		 */
		 catch (EPPAssemblerException e) {
			throw e;
		}

		/**
		 * EPPException comes from readPacket()...  Any EPPException is
		 * considered fatal...
		 */
		 catch (EPPException e) {
			cat.error("toEvent(InputStream):", e);
			e.printStackTrace();
			throw new EPPAssemblerException(
											e.getMessage(),
											EPPAssemblerException.FATAL);
		}
		 catch (InterruptedIOException e) {
			cat.error("toEvent(InputStream):", e);
			e.printStackTrace();
			throw new EPPAssemblerException(
											e.getMessage(),
											EPPAssemblerException.INTRUPTEDIO);
		}
		 catch (IOException e) {
			cat.error("toEvent(InputStream):", e);
			e.printStackTrace();
			throw new EPPAssemblerException(
											e.getMessage(),
											EPPAssemblerException.CLOSECON);
		}

		cat.debug("toEvent(InputStream): Return");

		return new EPPEvent(message);
	}

	/**
	 * Initialize the XML parser pool, with the name EPPXMLParser.POOL and with
	 * the "com.verisign.epp.util.EPPXMLParser" as the object type. The
	 * remaining configuration settings are retrieved from the
	 * EPPEnv.getServerParser methods.  If there is any error initializing the
	 * pool, and error diagnostic is logged, and the program with stop with a
	 * call to <code>System.exit(1)</code>, since this represents a fatal
	 * error.  The <code>EPPEnv</code> settings referenced include:<br><br>
	 * 
	 * <ul>
	 * <li>
	 * getServerParserInitObjs()
	 * </li>
	 * <li>
	 * getServerParserMinSize
	 * </li>
	 * <li>
	 * getServerParserMaxSize()
	 * </li>
	 * <li>
	 * getServerParserMaxSoft()
	 * </li>
	 * <li>
	 * getServerParserObjTimeout()
	 * </li>
	 * <li>
	 * getServerParserUserTimeout()
	 * </li>
	 * <li>
	 * getServerParserSkimmerFreq()
	 * </li>
	 * <li>
	 * getServerParserShrinkBy()
	 * </li>
	 * <li>
	 * getServerParserLogFile()
	 * </li>
	 * <li>
	 * getServerParserDebug()
	 * </li>
	 * </ul>
	 */
	private void initParserPool() {
		// Pool does not exist?
		if (!_parserInitialized) {
			// Create parser pool
			GenericPoolMetaData meta = new GenericPoolMetaData();

			meta.setName(EPPSchemaCachingParser.POOL);
			meta.setObjectType("com.verisign.epp.util.EPPSchemaCachingParser");
			meta.setInitialObjects(EPPEnv.getServerParserInitObjs());
			meta.setMinimumSize(EPPEnv.getServerParserMinSize());
			meta.setMaximumSize(EPPEnv.getServerParserMaxSize());
			meta.setMaximumSoft(EPPEnv.getServerParserMaxSoft());
			meta.setObjectTimeout(EPPEnv.getServerParserObjTimeout());
			meta.setUserTimeout(EPPEnv.getServerParserUserTimeout());
			meta.setSkimmerFrequency(EPPEnv.getServerParserSkimmerFreq());
			meta.setShrinkBy(EPPEnv.getServerParserShrinkBy());
			meta.setLogFile(EPPEnv.getServerParserLogFile());
			meta.setDebugging(EPPEnv.getServerParserDebug());

			GenericPool newPool = new GenericPool(meta);

			GenericPoolManager.getInstance().addPool(poolName, newPool);
			manager     = GenericPoolManager.getInstance();

			_parserInitialized = true;
		}
	}

	// End HttpEPPXMLAssembler.initParserPool()

	/**
	 * DOCUMENT ME!
	 *
	 * @param inStream DOCUMENT ME!
	 * @param aData DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 *
	 * @throws EPPException DOCUMENT ME!
	 * @throws IOException DOCUMENT ME!
	 * @throws EPPAssemblerException DOCUMENT ME!
	 */
	private Document readPacket(InputStream inStream, Object aData)
						 throws EPPException, IOException {
		// Validate argument
		if (inStream == null) {
			throw new EPPException("HttpEPPXMLAssembler.readPacket() : "
								   + "BAD ARGUMENT (aStream)");
		}

		DocumentBuilder theBuilder = null;
		Document	    theDoc = null;

		// Parser pool specified?
		if (manager != null) {
			theBuilder = (DocumentBuilder) manager.requestObject(poolName);

			/**
			 * Set the error handler of the parser to a Gln Error handler
			 */
			theBuilder.setErrorHandler(new HttpXMLErrorHandler());
		}
		else {
			// Create new parser instance.
			theBuilder = new EPPSchemaCachingParser();
		}

		try {
			String thePacket = null;

			try {
				/**
				 * This is where the implementation is different from
				 * EPPXMLStream.  We read the exact amount of data from the
				 * stream in one read.  This should improve performance.
				 */
				SessionData		   sessionData = (SessionData) aData;
				HttpServletRequest httpRequest =
					(HttpServletRequest) sessionData.getAttribute("servletRequest");

				int numBytesToRead = httpRequest.getContentLength();
				cat.debug("HttpEPPXMLAssembler.readPacket() determined"
						  + " packet size of: " + numBytesToRead);

				byte[]		    packetBytes = new byte[numBytesToRead];

				DataInputStream das = new DataInputStream(inStream);

				das.readFully(packetBytes, 0, numBytesToRead);

				cat.debug("HttpEPPXMLAssembler.readPacket() : Received ["
						  + new String(packetBytes) + "]");

				// Parse/validate EPP Packet and create DOM document
				theDoc =
					theBuilder.parse(new ByteArrayInputStream(packetBytes));

				cat.debug("Finished creating DOM document.");
			}
			 catch (EPPXMLErrorHandlerWarningException ex) {
				cat.warn("Caught warning while parsing doc", ex);

				Exception nestedException = ex.getException();

				if (nestedException instanceof SAXParseException) {
					SAXParseException saxEx =
						(SAXParseException) nestedException;

					cat.warn(thePacket + "\nline      " + saxEx.getLineNumber()
							 + "\ncolumn    " + saxEx.getColumnNumber()
							 + "\nuri       " + saxEx.getSystemId()
							 + "\nMessage : " + saxEx.getMessage());
				}
			}
			 catch (EPPXMLErrorHandlerErrorException ex) {
				Exception nestedException = ex.getException();

				if (nestedException instanceof SAXParseException) {
					SAXParseException saxEx =
						(SAXParseException) nestedException;

					cat.error(thePacket + "\nline      "
							  + saxEx.getLineNumber() + "\ncolumn    "
							  + saxEx.getColumnNumber() + "\nuri       "
							  + saxEx.getSystemId() + "\nMessage : "
							  + saxEx.getMessage());

					throw new EPPAssemblerException(
													thePacket + "\nline      "
													+ saxEx.getLineNumber()
													+ "\ncolumn    "
													+ saxEx.getColumnNumber()
													+ "\nuri       "
													+ saxEx.getSystemId()
													+ "\nMessage : "
													+ saxEx.getMessage(),
													EPPAssemblerException.XML);
				}

				throw new EPPException(thePacket);
			}

			 catch (EPPXMLErrorHandlerFatalException ex) {
				Exception nestedException = ex.getException();

				if (nestedException instanceof SAXParseException) {
					SAXParseException saxEx =
						(SAXParseException) nestedException;
					cat.error(thePacket + "\nline      "
							  + saxEx.getLineNumber() + "\ncolumn    "
							  + saxEx.getColumnNumber() + "\nuri       "
							  + saxEx.getSystemId() + "\nMessage : "
							  + saxEx.getMessage());

					throw new EPPAssemblerException(
													thePacket + "\nline      "
													+ saxEx.getLineNumber()
													+ "\ncolumn    "
													+ saxEx.getColumnNumber()
													+ "\nuri       "
													+ saxEx.getSystemId()
													+ "\nMessage : "
													+ saxEx.getMessage(),
													EPPAssemblerException.XML);
				}

				throw new EPPException(thePacket);
			}

			 catch (SAXParseException ex) {
				// Error generated by parser
				cat.error(thePacket + "\nline      " + ex.getLineNumber()
						  + "\ncolumn    " + ex.getColumnNumber()
						  + "\nuri       " + ex.getSystemId() + "\nMessage : "
						  + ex.getMessage());

				throw new EPPAssemblerException(
												thePacket + "\nline      "
												+ ex.getLineNumber()
												+ "\ncolumn    "
												+ ex.getColumnNumber()
												+ "\nuri       "
												+ ex.getSystemId()
												+ "\nMessage : "
												+ ex.getMessage(),
												EPPAssemblerException.XML);
			}
			 catch (SAXException ex) {
				// Error generated by this application
				cat.error("EPPEXMStream.read() : [SAXException ]" + thePacket
						  + ex);
				throw new EPPAssemblerException(
												"HttpEPPXMLAssembler."
												+ "readPacket() : "
												+ "[SAXException ]" + thePacket
												+ ex, EPPAssemblerException.XML);
			}
		}
		 finally {
			// Check in pool object
			if (manager != null) {
				manager.returnObject(theBuilder);
			}
		}

		return theDoc;
	}
}
