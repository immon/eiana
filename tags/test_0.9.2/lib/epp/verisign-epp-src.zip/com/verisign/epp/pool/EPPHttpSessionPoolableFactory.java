/***********************************************************
Copyright (C) 2004 VeriSign, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

http://www.verisign.com/nds/naming/namestore/techdocs.html
***********************************************************/
package com.verisign.epp.pool;


import org.apache.log4j.Logger;

import com.verisign.epp.interfaces.EPPSession;
import com.verisign.epp.util.EPPCatFactory;

/**
 * Customized <code>EPPSessionPoolableFactory</code> for creating a pool of 
 * {@link com.verisign.epp.interfaces.EPPHttpSession} objects.
 */
public class EPPHttpSessionPoolableFactory extends EPPSessionPoolableFactory {
		
	/** Log4j category for logging */
	private static Logger log =
		Logger.getLogger(
				EPPHttpSessionPoolableFactory.class.getName(),
				EPPCatFactory.getInstance().getFactory());
		
	/**
	 * Default constructor.  Must set the following attributes for using:<br>
	 * <br><ul>
	 * <li>clientId
	 * <li>password
	 * <li>absoluteTimeout
	 * <li>idleTimeout
	 * </ul>
	 */
	public EPPHttpSessionPoolableFactory() {
		super();
	}
	
	
	/**
	 * Create an EPP session poolable factory with the client id, password used 
	 * to authenticate the session.  The kind of EPP session created default to 
	 * <code>KIND_GENERIC</code>.  
	 * 
	 * @param aClientId Login id used to authenticate
	 * @param aPassword Password used to authenticate
	 * @param aAbsoluteTimeout Session absolute timeout
	 * @param aIdleTimeout Session idle timeout
	 */
	public EPPHttpSessionPoolableFactory(String aClientId, String aPassword, 
			long aAbsoluteTimeout, long aIdleTimeout) {
		super(aClientId, aPassword, aAbsoluteTimeout, aIdleTimeout);
	}
	
	
	/**
	 * Create an EPP session poolable factory with the client id, password, and 
	 * target URL for an HTTP connection.  The session kind is automatically 
	 * set to <cod>KIND_HTTP</code>.  
	 * 
	 * @param aClientId Login id used to authenticate
	 * @param aPassword Password used to authenticate
	 * @param aAbsoluteTimeout Session absolute timeout
	 * @param aIdleTimeout Session idle timeout
	 * @param aUrlWithPort URL used to connect to for an HTTP session
	 */
	public EPPHttpSessionPoolableFactory(String aClientId, String aPassword, 
			long aAbsoluteTimeout, long aIdleTimeout, String aUrlWithPort) {
		super(aClientId, aPassword, aAbsoluteTimeout, aIdleTimeout);
		super.setServerName(aUrlWithPort);
	}
	
	/**
	 * Make an HTTP EPP session instance for pool.
	 * 
	 * @return <code>EPPHttpSession</code> instance
	 */
	protected EPPSession makeSession() throws Exception {
		log.debug("makeSession(): enter");
		String theURL = super.getServerName();
		if (theURL != null) {
			log.debug("makeSession(): Creating with specified URL " + theURL);
			return new EPPPooledHttpSession(theURL);
		}
		else { 
			log.debug("makeSession(): Creating with default URL");
			return new EPPPooledHttpSession();
		}
	}
	
		
}
