/***********************************************************
Copyright (C) 2004 VeriSign, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

http://www.verisign.com/nds/naming/namestore/techdocs.html
***********************************************************/
package com.verisign.epp.pool;

import org.apache.log4j.Logger;

import com.verisign.epp.interfaces.EPPCommandException;
import com.verisign.epp.interfaces.EPPHttpSession;
import com.verisign.epp.util.EPPCatFactory;


/**
 * Pooled <code>EPPHttpSession</code>.  Timestamp attributes were added
 * to handle absolute session timeout and ensure that idle timeouts don't 
 * occur.  
 */
public class EPPPooledHttpSession extends EPPHttpSession implements EPPPooledSession {

	/** Log4j category for logging */
	private static Logger log =
		Logger.getLogger(
				EPPPooledHttpSession.class.getName(),
				EPPCatFactory.getInstance().getFactory());
		
	/**
	 * When pooled object was created
	 */
	private long createdTime = System.currentTimeMillis();
	
	/**
	 * Last time session was used or a keep alive was sent
	 */
	private long lastTouched = System.currentTimeMillis();
		
	/**
	 * Default constructor for <code>EPPPooledHttpSession</code>.
	 * 
	 * @throws EPPCommandException On error
	 */
	public EPPPooledHttpSession() throws EPPCommandException {
		super();
	}
	
	
	/**
	 * Default constructor for <code>EPPPooledHttpSession</code>.
	 * 
	 * @param aUrlWithPort URL of server
	 * 
	 * @throws EPPCommandException On error
	 */
	public EPPPooledHttpSession(String aUrlWithPort) throws EPPCommandException {
		super(aUrlWithPort);
	}
	
	
	/**
	 * Gets the time the pooled object was created.
	 * 
	 * @return Epoch time of creation
	 */
	public long getCreatedTime() {
		return createdTime;
	}
	
	/**
	 * Gets the last time the pooled object was touched.
	 * 
	 * @return Epoch time of touch
	 */
	public long getLastTouched() {
		return lastTouched;
	}
	
	/**
	 * Sets the last touched to the current time.
	 */
	public void touch() {
		this.lastTouched = System.currentTimeMillis();
	}
	
}