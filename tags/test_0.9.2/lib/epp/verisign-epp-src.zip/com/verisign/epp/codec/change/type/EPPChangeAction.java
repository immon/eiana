/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change.type;

import java.text.ParseException;
import java.util.Date;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.verisign.epp.codec.change.EPPChangeMapFactory;
import com.verisign.epp.codec.change.util.ExceptionUtil;
import com.verisign.epp.codec.change.util.TextUtil;
import com.verisign.epp.codec.change.util.TypeUtil;
import com.verisign.epp.codec.gen.EPPCodecComponent;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPUtil;
import com.verisign.epp.util.EqualityUtil;

/**
 * Encapsulates an Change:Action attached to a Change:Request.
 * @author jcolosi
 */
public class EPPChangeAction implements EPPCodecComponent {
	static public final String ELM_NAME = "change:action";

	private String requestId = null;
	private String clientTransId = null;
	private String serverTransId = null;
	private String definition = null;
	private Date createdDate = null;
	private Date updatedDate = null;

	public EPPChangeAction() {}

	public EPPChangeAction(String requestId, String clientTransId, String serverTransId) {
		setRequestId(requestId);
		setClientTransId(clientTransId);
		setServerTransId(serverTransId);
	}

	public EPPChangeAction(String requestId, String serverTransId) {
		setRequestId(requestId);
		setServerTransId(serverTransId);
	}

	public EPPChangeAction(Element element) throws EPPDecodeException {
		decode(element);
	}

	public Object clone() throws CloneNotSupportedException {
		return (EPPChangeAction) super.clone();
	}

	/**
	 * Decode the EPPChangeAction attributes from the DOM Element tree.
	 * @param aElement - Root DOM Element to decode
	 * @exception EPPDecodeException Unable to decode aElement
	 * @throws ParseException
	 */
	public void decode(Element aElement) throws EPPDecodeException {
		try {
			/**
			 * LOGIC: Decode nested elements
			 */
			NodeList nodes = aElement.getChildNodes();
			if (nodes != null) {
				int size = nodes.getLength();
				for (int i = 0; i < size; i++) {
					Node node = nodes.item(i);
					if (node instanceof Element) {
						String name = node.getNodeName();
						if (name.equals(TypeUtil.ELM_REQUESTID)) setRequestId(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_CLIENT_TRANS_ID)) setClientTransId(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_SERVER_TRANS_ID)) setServerTransId(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_DEFINITION)) setDefinition(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_CREATED_DATE)) setCreatedDate(EPPUtil
								.getTextContent(node));
						else if (name.equals(TypeUtil.ELM_UPDATED_DATE)) setUpdatedDate(EPPUtil
								.getTextContent(node));
					}
				}
			}
		} catch (ParseException x) {
			throw new EPPDecodeException(x.getMessage());
		}

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForDecode(serverTransId, TypeUtil.ELM_SERVER_TRANS_ID);
	}

	/**
	 * Encode a DOM Element tree from the attributes of the EPPChangeTld
	 * instance.
	 * @param aDocument - DOM Document that is being built. Used as an Element
	 *            factory.
	 * @return Element - Root DOM Element representing the EPPChangeTld
	 *         instance.
	 * @exception EPPEncodeException - Unable to encode EPPChangeTld instance.
	 */
	public Element encode(Document aDocument) throws EPPEncodeException {
		Element root = aDocument.createElementNS(EPPChangeMapFactory.NS, ELM_NAME);

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForEncode(serverTransId, TypeUtil.ELM_SERVER_TRANS_ID);

		EPPUtil.encodeString(aDocument, root, requestId, EPPChangeMapFactory.NS,
				TypeUtil.ELM_REQUESTID);
		EPPUtil.encodeString(aDocument, root, clientTransId, EPPChangeMapFactory.NS,
				TypeUtil.ELM_CLIENT_TRANS_ID);
		EPPUtil.encodeString(aDocument, root, serverTransId, EPPChangeMapFactory.NS,
				TypeUtil.ELM_SERVER_TRANS_ID);
		EPPUtil.encodeString(aDocument, root, definition, EPPChangeMapFactory.NS,
				TypeUtil.ELM_DEFINITION);
		TextUtil.encodeDate(aDocument, root, createdDate, EPPChangeMapFactory.NS,
				TypeUtil.ELM_CREATED_DATE);
		TextUtil.encodeDate(aDocument, root, updatedDate, EPPChangeMapFactory.NS,
				TypeUtil.ELM_UPDATED_DATE);

		return root;
	}

	/**
	 * Implements a deep <code>EPPChangeAction</code> compare
	 * @param aObject <code>EPPChangeAction</code> instance
	 * @return DOCUMENT ME!
	 */
	public boolean equals(Object o) {
		if ((o == null) || (!o.getClass().equals(this.getClass()))) return false;
		EPPChangeAction other = (EPPChangeAction) o;

		return EqualityUtil.equals(this.requestId, other.requestId)
				&& EqualityUtil.equals(this.clientTransId, other.clientTransId)
				&& EqualityUtil.equals(this.serverTransId, other.serverTransId)
				&& EqualityUtil.equals(this.definition, other.definition)
				&& EqualityUtil.equals(this.createdDate, other.createdDate)
				&& EqualityUtil.equals(this.updatedDate, other.updatedDate);
	}

	public String getClientTransId() {
		return clientTransId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public String getCreatedDateString() {
		return TextUtil.encodeDate(createdDate);
	}

	public String getDefinition() {
		return definition;
	}

	public String getRequestId() {
		return requestId;
	}

	public String getServerTransId() {
		return serverTransId;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public String getUpdatedDateString() {
		return TextUtil.encodeDate(updatedDate);
	}

	public void setClientTransId(String clientTransId) {
		this.clientTransId = TextUtil.normalize(clientTransId);
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = TextUtil.normalize(createdDate);
	}

	public void setCreatedDate(String createdDate) throws ParseException {
		this.createdDate = TextUtil.decodeDate(createdDate);
	}

	public void setDefinition(String definition) {
		this.definition = TextUtil.normalize(definition);
	}

	public void setRequestId(String requestId) {
		this.requestId = TextUtil.normalize(requestId);
	}

	public void setServerTransId(String serverTransId) {
		this.serverTransId = TextUtil.normalize(serverTransId);
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = TextUtil.normalize(updatedDate);
	}

	public void setUpdatedDate(String updatedDate) throws ParseException {
		this.updatedDate = TextUtil.decodeDate(updatedDate);
	}

	public String toLogString() {
		return clientTransId + "," + serverTransId;
	}

	/**
	 * Implementation of <code>Object.toString</code>, which will result in
	 * an indented XML <code>String</code> representation of the concrete
	 * <code>EPPCodecComponent</code>.
	 * @return Indented XML <code>String</code> if successful;
	 *         <code>ERROR</code> otherwise.
	 */
	public String toString() {
		return EPPUtil.toString(this);
	}
}