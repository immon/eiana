/***********************************************************
Copyright (C) 2004 VeriSign, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

http://www.verisign.com/nds/naming/namestore/techdocs.html
***********************************************************/

/**
 * The information in this document is proprietary to VeriSign and the VeriSign
 * Registry Business. It may not be used, reproduced or disclosed without the
 * written approval of the General Manager of VeriSign Global Registry
 * Services. PRIVILEDGED AND CONFIDENTIAL VERISIGN PROPRIETARY INFORMATION
 * REGISTRY SENSITIVE INFORMATION Copyright (c) 2003 VeriSign, Inc.  All
 * rights reserved.
 */
package com.verisign.epp.interfaces;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.httpclient.HostConfiguration;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpConnection;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.SimpleHttpConnectionManager;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;
import org.apache.log4j.Logger;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import com.codestudio.util.GenericPoolManager;

import com.verisign.epp.codec.gen.EPPCommand;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPGreeting;
import com.verisign.epp.codec.gen.EPPHello;
import com.verisign.epp.codec.gen.EPPLoginCmd;
import com.verisign.epp.codec.gen.EPPLogoutCmd;
import com.verisign.epp.codec.gen.EPPResponse;
import com.verisign.epp.transport.client.EPPSSLImpl;
import com.verisign.epp.util.EPPCatFactory;
import com.verisign.epp.util.EPPEnv;
import com.verisign.epp.util.EPPEnvException;
import com.verisign.epp.util.EPPSchemaCachingParser;


/**
 * EPPHttpSession provides behavior for communicating with an EPP Server using
 * the HTTP protocol as the transport.
 */
public class EPPHttpSession extends EPPSession {
	/** Log4j category for logging */
	private static Logger cat =
		Logger.getLogger(
						 EPPHttpSession.class.getName(),
						 EPPCatFactory.getInstance().getFactory());

	/** HttpClient instance that we delegate to */
	private HttpClient httpClient = new HttpClient();

	/**
	 * The cookie that the server returns to identify the session instance
	 *
	 * @todo - is this still necessary?
	 */
	private String cookie = null;

	/** Flag to see if a session is established */
	private boolean sessionEstablished = false;

	/** The connection timeout in seconds.  The default is 60 seconds. */
	private int connectionTimeout = 0;

	/** The buffer size (in chars) of the outbound XML buffer. */
	private int bufferSize = 500;

	/** The URL with port to connect to. */
	private String urlWithPort = null;

	/** Whether to use HTTP KeepAlive connections */
	private boolean useHttpKeepAlive = true;

	/**
	 * Pool Manager that could contain the EPP XML Parser Pool
	 * (<code>poolName</code>).  If this is <code>null</code> there will be
	 * one XML parser created per call to <code>read</code>.
	 */
	private GenericPoolManager manager = null;

	/** Name of XML Parser Pool contained in <code>manager</code>. */
	private String poolName = null;

	/**
	 * Construct an EPPHttpSession instance that points to the given URL and
	 * port.  e.g https://test.vgrs.com/nsgateway/epp/controller
	 *
	 * @param aUrlWithPort
	 *
	 * @throws EPPCommandException
	 */
	public EPPHttpSession(String aUrlWithPort) throws EPPCommandException {
		super();

		this.urlWithPort = aUrlWithPort;

		/**
		 * Set the socket timeout (SO_TIMEOUT) in milliseconds based 
		 * on the <code>ConTimeOut</code> setting.
		 */ 
		try {
			httpClient.setTimeout(EPPEnv.getConTimeOut());
		}
		catch (EPPEnvException e) {
			cat.error("Error when trying to get ConTimeOut property", e);
			throw new EPPCommandException("Error when trying to get ConTimeOut property"
										  + e.getMessage());			
		}
		
		httpClient.setConnectionTimeout(connectionTimeout * 1000);
		
		
		// Initialize SSL if required
		this.initSSL();
		
		HostConfiguration hostConfiguration = new HostConfiguration();
		hostConfiguration.setHost(urlWithPort);
		httpClient.setHostConfiguration(hostConfiguration);

		// Set stale checking to false to correctly implement
		// http keep-alive connections
		SimpleHttpConnectionManager connManager =
			(SimpleHttpConnectionManager) httpClient.getHttpConnectionManager();

		connManager.setConnectionStaleCheckingEnabled(false);

		// setup parser pool
		manager		 = GenericPoolManager.getInstance();
		poolName     = EPPSchemaCachingParser.POOL;
	}

	/**
	 * Construct an <code>EPPHttpSession</code>, which will do the
	 * following:<br>
	 * 
	 * <ol>
	 * <li>
	 * Instantiate a commons HttpCient instance.
	 * </li>
	 * </ol>
	 * 
	 * <br><code>EPPHttpSession.initSession</code> needs to be called to fully
	 * initialize a session with the EPP Server.
	 *
	 * @exception EPPCommandException Error initializing the
	 * 			  <code>EPPSession</code>
	 */
	public EPPHttpSession() throws EPPCommandException {
		super();
		
		/**
		 * Set the socket timeout (SO_TIMEOUT) in milliseconds based 
		 * on the <code>ConTimeOut</code> setting.
		 */ 
		try {
			httpClient.setTimeout(EPPEnv.getConTimeOut());
		}
		catch (EPPEnvException e) {
			cat.error("Error when trying to get ConTimeOut property", e);
			throw new EPPCommandException("Error when trying to get ConTimeOut property"
										  + e.getMessage());			
		}
		
		httpClient.setConnectionTimeout(connectionTimeout * 1000);

		try {
			urlWithPort = EPPEnv.getServerName();
		}
		 catch (EPPEnvException e) {
			cat.error("Error when trying to get EPP Server name ", e);
			throw new EPPCommandException("Error when trying to get EPP Server name"
										  + e.getMessage());
		}

		// Initialize SSL if required
		this.initSSL();
		 
		HostConfiguration hostConfiguration = new HostConfiguration();
		hostConfiguration.setHost(urlWithPort);
		httpClient.setHostConfiguration(hostConfiguration);

		// Set stale checking to false to correctly implement
		// http keep-alive connections
		SimpleHttpConnectionManager connManager =
			(SimpleHttpConnectionManager) httpClient.getHttpConnectionManager();

		connManager.setConnectionStaleCheckingEnabled(false);

		// setup parser pool
		manager		 = GenericPoolManager.getInstance();
		poolName     = EPPSchemaCachingParser.POOL;
	}
	
	/**
	 * Initializes SSL if required and the <code>urlWithPort</code> attribute 
	 * is for https.
	 * 
	 * @throws EPPCommandException Error initializing SSL 
	 */
	private void initSSL() throws EPPCommandException {
		
		try {
			// Ensure EPPSSLImpl and HttpsURLConnection is initialized for https
			if (this.urlWithPort.startsWith("https") && !EPPSSLImpl.isInitialized()) {
				cat.info("EPPHttpSession: Initializing EPPSSLImpl and HttpsURLConnection");
				EPPSSLImpl.initialize();
				
				// Register socket factory with HTTP Client for https connections
				Protocol theHTTPSProtocol = new Protocol("https",
						new HTTPSSocketFactory(EPPSSLImpl.getSSLSocketFactory()), 443);
				Protocol.registerProtocol("https", theHTTPSProtocol);
			}			
		}
		catch (Exception ex) {
			cat.error("EPPHttpSession.initSSL: Error initializing EPPSSLImpl", ex);
			throw new EPPCommandException("EPPHttpSession.initSSL: Error initializing EPPSSLImpl: "
										  + ex.getMessage());						
		}
	 
	}

	/**
	 * Helper method called by constructor to perform any initialization
	 * required for the EPPHttpSession class.
	 *
	 * @throws EPPCommandException
	 */
	public void init() throws EPPCommandException {
	}

	/**
	 * Gets this instances jakarta HttpClient instance
	 *
	 * @return This instances jakarta HttpClient instance
	 */
	public HttpClient getHttpClient() {
		return httpClient;
	}

	/**
	 * Sets this instance's jakarta HttpClient instance
	 *
	 * @param aHttpClient The jakarta HttpClient instance to use.
	 */
	public void setHttpClient(HttpClient aHttpClient) {
		httpClient = aHttpClient;
	}

	/**
	 * Setter to use HTTP Keep Alive connections
	 *
	 * @param aUseKeepAlive Should be set to true to turn on keep alive
	 */
	public void setHttpKeepAlive(boolean aUseKeepAlive) {
		useHttpKeepAlive = aUseKeepAlive;
	}

	/**
	 * Whether HTTP Keep Alive connections are being used by this
	 * EPPHttpSession
	 *
	 * @return True if HTTP Keep alive is being used
	 */
	public boolean isUsingHttpKeepAlive() {
		return useHttpKeepAlive;
	}

	/**
	 * Returns an instance of a DocumentBuilder.  If a pool has been specified
	 * it returns the parser from the pool.  Otherwise it instantiates a new
	 * parser.
	 *
	 * @return an instance of a Document Builder
	 *
	 * @throws EPPCommandException DOCUMENT ME!
	 */
	private DocumentBuilder getParser() throws EPPCommandException {
		DocumentBuilder theBuilder = null;

		// Parser pool specified?
		if (manager != null) {
			theBuilder = (DocumentBuilder) manager.requestObject(poolName);
		}
		else {
			DocumentBuilderFactory factory =
				DocumentBuilderFactory.newInstance();
			factory.setValidating(EPPEnv.getValidating());
			factory.setNamespaceAware(true);

			// Create new parser instance.
			theBuilder = new EPPSchemaCachingParser();
		}

		return theBuilder;
	}

	/**
	 * Helper method to send an XML payload in an HTTP POST method.
	 *
	 * @param someXml The XML to send.
	 *
	 * @return The XML that is returned from the server.
	 *
	 * @throws EPPCommandException DOCUMENT ME!
	 */
	public String postXml(String someXml) throws EPPCommandException {
		cat.debug("postXml() enter");

		PostMethod post = new PostMethod(urlWithPort);

		// Request content will be retrieved directly
		// from the input stream
		post.setRequestBody(someXml);

		cat.info("Sending: " + someXml);

		byte[] bytes = someXml.getBytes();

		// Per default, the request content needs to be buffered
		// in order to determine its length.
		// Request body buffering can be avoided when
		// = content length is explicitly specified
		// = chunk-encoding is used
		post.setRequestContentLength((int) bytes.length);

		// Specify content type and encoding
		// If content encoding is not explicitly specified
		// ISO-8859-1 is assumed
		post.setRequestHeader("Content-type", "text/xml; charset=ISO-8859-1");

		int    result = 200;
		String ret = null;

		try {
			result     = httpClient.executeMethod(post);

			ret = post.getResponseBodyAsString();
		}
		 catch (IOException e) {
			cat.error("Couldn't execute HTTP POST to server " + urlWithPort, e);
			cat.error("HTTP return code: " + result);
			throw new EPPCommandException("Received IOException: "
										  + e.getMessage());
		}
		 finally {
			post.releaseConnection();
		}

		cat.info("Received: " + ret);

		if (ret == null) {
			cat.error("response body was null after executing HTTP POST. ");
			throw new EPPCommandException("Didn't get response body in response "
										  + " from server when HTTP POST");
		}

		cat.debug("postXml() exit");

		return ret;
	}

	/**
	 * Sends a Hello Command to the EPP Server.  The EPP Greeting from the EPP
	 * Server will be returned.
	 *
	 * @return DOCUMENT ME!
	 *
	 * @exception EPPCommandException Thrown if any exception occurs.
	 */
	public EPPGreeting hello() throws EPPCommandException {
		cat.debug("hello() enter");

		// create EPPHello instance
		EPPHello helloCmd = new EPPHello();

		// Get Document form the the hello command
		Document helloDoc = null;

		try {
			helloDoc = myCodec.encode(helloCmd);
		}
		 catch (EPPEncodeException e) {
			throw new EPPCommandException("hello() encoding the EPPHello command : "
										  + e.getMessage());
		}

		// get String form of the command
		String helloXml = getStringFromDoc(helloDoc);

		// send the command to the server
		String resp = postXml(helloXml);

		// create a DOM tree from the returned response
		Document helloResponseDoc = getDocFromString(resp);

		// create an EPPGreeting instance from this DOM structure
		EPPGreeting greeting = null;

		try {
			greeting = myCodec.decodeGreeting(helloResponseDoc);
		}
		 catch (EPPDecodeException e) {
			cat.error(
					  "hello() failed while decoding an expected EPP Greeting ",
					  e);
			throw new EPPCommandException("hello() decode [EppDecodeException]: "
										  + e.getMessage());
		}
		 catch (Exception e) {
			cat.error(
					  "hello() failed while decoding an expected EPP Greeting ",
					  e);
			throw new EPPCommandException("EPPSession.Hello() decode [Runtime Exception] : "
										  + e.getMessage());
		}

		return greeting;
	}

	/**
	 * Ends a session by logging out from the server and closing the connection
	 * with the server.
	 *
	 * @exception EPPCommandException Error ending session
	 */
	public void endSession() throws EPPCommandException {
		try {
			logout();
		}
		finally {
			// Ensure that the physical connection is closed
			try {
				endConnection();
			}
			catch (Exception ex) {
				// Ignore
			}
		}
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @throws EPPCommandException
	 *
	 * @todo implement
	 */
	public void endConnection() throws EPPCommandException {
		cat.debug("endConnection() enter");

		HostConfiguration hostConfiguration = httpClient.getHostConfiguration();
		HttpConnection    connection =
			httpClient.getHttpConnectionManager().getConnection(hostConfiguration);

		connection.releaseConnection();

		cat.debug("endConnection() exit");
	}

	/**
	 * Process an <code>EPPCommand</code> instance by writing the command to
	 * the server and reading an <code>EPPResponse</code> instance from the
	 * server.
	 *
	 * @param aCommand The EPP Commmand instance to send to the server
	 *
	 * @return An EPPResponse instance
	 *
	 * @exception EPPCommandException error processing the command.  This can
	 * 			  include an error specified from the server or encountered
	 * 			  while attempting to process the command.  If the exception
	 * 			  contains an <code>EPPResponse</code> than it was a server
	 * 			  specified error.
	 */
	public EPPResponse processDocument(EPPCommand aCommand)
								throws EPPCommandException {
		cat.debug("processDocument(aCommand) enter");

		Document doc = null;

		// get DOM Document form of the the command;
		try {
			doc = myCodec.encode(aCommand);
		}
		 catch (EPPEncodeException e) {
			cat.error("Encode Exception while in processDocument()");
			throw new EPPCommandException("processDocument: encodingCommand "
										  + e.getMessage());
		}

		// Get String form of the DOM Document
		String sendXml = getStringFromDoc(doc);

		// Send the Command and get the response
		String respXml = postXml(sendXml);

		// get the DOM form of the returned XML
		Document responseDocument = getDocFromString(respXml);

		// Use the codec to get the EPPResponse form of the response
		EPPResponse response = null;

		try {
			response = myCodec.decodeResponse(responseDocument);
		}
		 catch (EPPDecodeException e) {
			cat.error("Decode Exception while in processDocument() decoding response");
			throw new EPPCommandException("processDocument().  Error decoding response from server"
										  + e.getMessage());
		}

		// Throw an exception containing the response if the the response
		// wasn't success.
		if (!response.isSuccess()) {
			throw new EPPCommandException(
										  "processDocument() : Error in response from Server",
										  response);
		}

		/**
		 * Make Sure Trans Id Mathes
		 */
		// validate the transaction id
		validateClientTransId(aCommand, response);

		cat.debug("processDocument(aCommand) exit");

		return response;
	}

	/**
	 * Establishes a session with the EPP Server. 1- Performs HTTP Get method.
	 * 2- Receives the EPP Greeting 3- Sends in the login message. 4-
	 * processes the response.
	 *
	 * @exception EPPCommandException Thrown if any errors are encountered
	 * 			  during IO, response validation, invalid login attempts, or
	 * 			  if the Greeting service menu doesn't match the services
	 * 			  listed in the EPPLogin command.
	 */
	protected void login() throws EPPCommandException {
		cat.debug("login() enter");

		// Use an HTTP GET method to get the EPPGreeting
		GetMethod method = new GetMethod(urlWithPort);

		// Keep the connection alive if specified
		if (useHttpKeepAlive) {
			method.setRequestHeader("Connection", "Keep-Alive");
		}

		cat.info("Connecting to server " + urlWithPort + " using HTTP GET");

		// get the response body
		String resp = null;

		try {
			httpClient.executeMethod(method);

			// get the response body
			resp = method.getResponseBodyAsString();
		}
		 catch (HttpException e) {
			cat.error("Couldn't execute HTTP GET to server " + urlWithPort, e);
			throw new EPPCommandException("Received HttpException: "
										  + e.getMessage());
		}
		 catch (IOException e) {
			cat.error("Couldn't execute HTTP GET to server " + urlWithPort, e);
			throw new EPPCommandException("Received HttpException: "
										  + e.getMessage());
		}
		 finally {
			// make the connection available for other methods
			method.releaseConnection();
		}

		// throw exception here if no response could be found
		if (resp == null) {
			cat.error("response body was null after executing HTTP GET.  Check the URL setting.");
			throw new EPPCommandException("Didn't get response body in response "
										  + " from server when sending initial GET");
		}

		cat.info("Received: " + resp);
		cat.debug("Validating response with DOM API...");

		// parse the response using the DOM and EPPCodec APIs.
		Document doc = getDocFromString(resp);

		// Use the DOM document as input to the EPPCodec to get an EPPGreeting
		cat.debug("Using EPP Codec to instantiate EPPGreeting...");

		EPPGreeting greeting = null;

		try {
			greeting = myCodec.decodeGreeting(doc);
		}
		 catch (EPPDecodeException e) {
			cat.error("Caught EPPDecode exception while trying to decode EPPGreeting "
					  + e.getMessage());

			throw new EPPCommandException("EPPSession.Login() decode [EppDecodeException]: "
										  + e.getMessage());
		}

		cat.debug("Successfully decoded the returned EPPGreeting");

		// setup the login command
		EPPLoginCmd loginCommand = setupLoginCommand();

		// Verify that the Greeting and Login services are compatible.
		cat.debug("Verifying that client service list is a subset of the server services...");

		if (!loginCommand.isValidServices(greeting)) {
			cat.warn("Login services does not match the greeting services, greeting = ["
					  + greeting + "], login = ["
					  + loginCommand + "]");
		}

		// create the DOM form of the EPPLogin command
		Document loginDocument = null;

		try {
			loginDocument = myCodec.encode(loginCommand);
		}
		 catch (EPPEncodeException e) {
			throw new EPPCommandException("login() encode : " + e.getMessage());
		}

		// Get the document as a String.
		String loginXml = getStringFromDoc(loginDocument);

		// send the XML in an HTTP POST and get the response
		String   responseXml = postXml(loginXml);

		Document loginRespDocument = getDocFromString(responseXml);

		cat.debug("Using EPP Codec to instantiate EPPResponse ...");

		EPPResponse response = null;

		try {
			response = myCodec.decodeResponse(loginRespDocument);
		}
		 catch (EPPDecodeException e) {
			cat.error("Caught EPPDecode exception while trying to decode response"
					  + e.getMessage());

			throw new EPPCommandException("EPPSession.Login() decode [EppDecodeException]: "
										  + e.getMessage());
		}

		cat.debug("Successfully decoded the returned EPP Response");

		// Check if there was an EPP error
		if (!response.isSuccess()) {
			throw new EPPCommandException(
										  "login() : Error in response from Server ",
										  response);
		}

		// verify the trans id
		validateClientTransId(loginCommand, response);

		// We've established a session...
		sessionEstablished     = true;

		// Reset the transaction id
		myTransId = null;
	}

	/**
	 * Takes in the header field of an HTTP Response that contains the cookie
	 * value for example:
	 * JSESSIONID=To1023mC27008564127672674At;Version=1;Discard;Path="/" and
	 * stores the cookie value that needs to be send in subsequent client
	 * requests:
	 *
	 * @throws EPPCommandException DOCUMENT ME!
	 */

	//    public void storeCookie(String cookieHeaderField) {
	//
	//
	//        StringTokenizer toker = new StringTokenizer(cookieHeaderField, ";");
	//        while (toker.hasMoreTokens()) {
	//
	//            String next = toker.nextToken();
	//            if (next.startsWith("JSESSIONID=")) {
	//                cookie = next;
	//                cat.debug("set cookie to: " + cookie);
	//            }
	//        }
	//    }
	protected void logout() throws EPPCommandException {
		cat.debug("logout() enter");

		EPPLogoutCmd logoutCmd = new EPPLogoutCmd();

		EPPResponse  response = processDocument(logoutCmd);

		/**
		 * Server specified error?
		 */
		if (!response.isSuccess()) {
			throw new EPPCommandException("logout() : Error in response from Server ");
		}

		sessionEstablished = false;

		cat.debug("logout() exit)");
	}

	/**
	 * A no op in the the EPPHttpSession implementation.
	 *
	 * @param aDocument DOCUMENT ME!
	 *
	 * @throws EPPCommandException DOCUMENT ME!
	 */
	protected void sendDocument(Document aDocument) throws EPPCommandException {
		throw new EPPCommandException("sendDocument() is not implemented for EPPHttpSession.");
	}

	/**
	 * A no op in the the EPPHttpSession implementation.
	 *
	 * @return DOCUMENT ME!
	 *
	 * @throws EPPCommandException DOCUMENT ME!
	 */
	protected Document recDocument() throws EPPCommandException {
		throw new EPPCommandException("recDocument() is not implemented for EPPHttpSession.");
	}

	/**
	 * Given an XML String returns its DOM equivalent.
	 *
	 * @param aXmlString
	 *
	 * @return
	 *
	 * @throws EPPCommandException
	 */
	private Document getDocFromString(String aXmlString)
							   throws EPPCommandException {
		cat.debug("getDocFromString() enter");

		DocumentBuilder parser = getParser();

		// Parse the response with the XML parser possibly validating it.
		Document doc = null;

		try {
			doc = parser.parse(new ByteArrayInputStream(aXmlString.getBytes()));
		}
		 catch (SAXException e) {
			cat.error(
					  "Encountered error while parsing response: " + aXmlString,
					  e);
			cat.error(
					  "Response couldn't be successfully parsed by DocumentBuilder instance "
					  + e.getMessage(), e);

			throw new EPPCommandException("Couldn't parse response using DOM API"
										  + aXmlString + e.getMessage());
		}
		 catch (IOException e) {
			cat.error("Encountered error while parsing response: " + aXmlString);
			cat.error("Response couldn't be parsed by DocumentBuilder instance "
					  + e.getMessage());

			throw new EPPCommandException("Couldn't parse response using DOM API"
										  + aXmlString + e.getMessage());
		}
		 finally {
			// return the parser to the pool
			if (manager != null) {
				manager.returnObject(parser);
			}
		}

		cat.debug("getDocFromString() exit");

		return doc;
	}

	/**
	 * Given a DOM document returns its String equivalent.
	 *
	 * @param aDocument
	 *
	 * @return
	 *
	 * @throws EPPCommandException
	 */
	private String getStringFromDoc(Document aDocument)
							 throws EPPCommandException {
		cat.debug("getDomString() enter");

		if (aDocument == null) {
			cat.error("getDomString(Document): aDocument == null");
			throw new EPPCommandException("getDomString() : BAD ARGUMENT (aDocument)");
		}

		// create a temporary destination for the XML payload;
		StringWriter  writer	    = new StringWriter(bufferSize);
		XMLSerializer xmlSerializer =
			new XMLSerializer(writer, (OutputFormat) null);

		try {
			xmlSerializer.serialize(aDocument);
		}
		 catch (IOException e) {
			cat.error(
					  "sendDocument(aDocument) : serialize() :"
					  + e.getMessage(), e);

			throw new EPPCommandException("sendDocument() : serialize() "
										  + e.getMessage());
		}

		cat.debug("getDomString() exit");

		return writer.getBuffer().toString();
	}

	/**
	 * Helper method to setup a login command with the username, password,
	 * version and lang values.
	 *
	 * @return an EPPLoginCmd instance
	 */
	private EPPLoginCmd setupLoginCommand() {
		EPPLoginCmd loginCommand = null;

		if (myNewPassword == null) {
			loginCommand = new EPPLoginCmd(myTransId, myClientID, myPassword);
		}
		else {
			loginCommand =
				new EPPLoginCmd(
								myTransId, myClientID, myPassword, myNewPassword);
		}

		if (myVersion != null) {
			loginCommand.setVersion(myVersion);
		}

		if (myLanguage != null) {
			loginCommand.setLang(myLanguage);
		}

		// Set the client specified services (setServices)
		if (myServices != null) {
			loginCommand.setServices(myServices);
		}

		return loginCommand;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public int getConnectionTimeout() {
		return connectionTimeout;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param connectionTimeout DOCUMENT ME!
	 */
	public void setConnectionTimeout(int connectionTimeout) {
		this.connectionTimeout = connectionTimeout;

		if (httpClient != null) {
			httpClient.setConnectionTimeout(connectionTimeout);
		}
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public String getUrlWithPort() {
		return urlWithPort;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param urlWithPort DOCUMENT ME!
	 */
	public void setUrlWithPort(String urlWithPort) {
		this.urlWithPort = urlWithPort;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public int getBufferSize() {
		return bufferSize;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param bufferSize DOCUMENT ME!
	 */
	public void setBufferSize(int bufferSize) {
		this.bufferSize = bufferSize;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public String getPoolName() {
		return poolName;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param poolName DOCUMENT ME!
	 */
	public void setPoolName(String poolName) {
		this.poolName = poolName;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public GenericPoolManager getManager() {
		return manager;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param manager DOCUMENT ME!
	 */
	public void setManager(GenericPoolManager manager) {
		this.manager = manager;
	}
	
	/**
	 * Custom HTTP Client Socket Factory that wraps a JDK
	 * <code>SSLSocketFactory</code> initialized from an
	 * <code>SSLContext</code>.
	 */
	private static class HTTPSSocketFactory implements ProtocolSocketFactory {

		/**
		 * Wrapped factory
		 */
		SSLSocketFactory factory;

		/**
		 * Instantiate an <cod>HTTPSSocketFactory</code> that wraps a <code>SSLSocketFactory</code>
		 * for integration of an <code>SSLContext</code> when creating HTTPS
		 * connection in HTTP Client.
		 * 
		 * @param aFactory
		 *            Factory to wrap
		 */
		public HTTPSSocketFactory(SSLSocketFactory aFactory) {
			this.factory = aFactory;
		}

		/**
		 * Creates socket for HTTPS connection.
		 * 
		 * @param host
		 *            Host to connect to
		 * @param port
		 *            Port to connect to
		 * 
		 * @return HTTPS socket
		 * 
		 * @throws IOException
		 * @throws UnknownHostException
		 */
		public Socket createSocket(String host, int port) throws IOException,
				UnknownHostException {
			SSLSocket theSocket = (SSLSocket) this.factory.createSocket(host, port);
			
			if (EPPSSLImpl.hasSSLEnabledProtocols()) {
				theSocket.setEnabledProtocols(EPPSSLImpl.getSSLEnabledProtocols());
			}
			
			return theSocket;
		}

		/**
		 * Creates socket for HTTPS connection.
		 * 
		 * @param host
		 *            Host to connect to
		 * @param port
		 *            Port to connect to
		 * @param clientHost
		 *            Host to connect from
		 * @param clientPort
		 *            Port to connect from
		 * 
		 * @return HTTPS socket
		 * 
		 * @throws IOException
		 * @throws UnknownHostException
		 */
		public Socket createSocket(String host, int port,
				InetAddress clientHost, int clientPort) throws IOException,
				UnknownHostException {
			SSLSocket theSocket =  (SSLSocket) this.factory.createSocket(host, port, clientHost, clientPort);
			
			if (EPPSSLImpl.hasSSLEnabledProtocols()) {
				theSocket.setEnabledProtocols(EPPSSLImpl.getSSLEnabledProtocols());
			}
			
			return theSocket;			
		}
		
	}
	
}
