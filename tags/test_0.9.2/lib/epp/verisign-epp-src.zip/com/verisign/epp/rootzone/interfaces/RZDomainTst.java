/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.rootzone.interfaces;

// ----------------------------------------------
//
// imports...
//
// ----------------------------------------------
// Java Core Imports

import java.util.Random;

import junit.extensions.TestSetup;
import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.apache.log4j.Logger;

import com.verisign.epp.codec.domain.EPPDomainCheckResp;
import com.verisign.epp.codec.domain.EPPDomainCheckResult;
import com.verisign.epp.codec.domain.EPPDomainContact;
import com.verisign.epp.codec.domain.EPPDomainCreateResp;
import com.verisign.epp.codec.domain.EPPDomainInfoResp;
import com.verisign.epp.codec.domain.EPPDomainMapFactory;
import com.verisign.epp.codec.domain.EPPDomainStatus;
import com.verisign.epp.codec.gen.EPPFactory;
import com.verisign.epp.codec.gen.EPPResponse;
import com.verisign.epp.codec.gen.EPPResult;
import com.verisign.epp.interfaces.EPPApplicationSingle;
import com.verisign.epp.interfaces.EPPCommandException;
import com.verisign.epp.interfaces.EPPDomain;
import com.verisign.epp.interfaces.EPPSession;
import com.verisign.epp.pool.EPPSessionPool;
import com.verisign.epp.util.EPPCatFactory;
import com.verisign.epp.util.InvalidateSessionException;
import com.verisign.epp.util.TestThread;
import com.verisign.epp.util.TestUtil;

/**
 * Test of the use of the <code>NSDomain</code> interface. This test utilizes
 * the EPP session pool and exercises all of the operations defined in
 * <code>NSDomain</code> and the base class <code>EPPDomain</code>.
 * @see com.verisign.epp.namestore.interfaces.NSDomain
 * @see com.verisign.epp.interfaces.EPPDomain
 */
public class RZDomainTst extends TestCase {

	/**
	 * Handle to the Singleton EPP Application instance (<code>EPPApplicationSingle</code>)
	 */
	private static EPPApplicationSingle app = EPPApplicationSingle.getInstance();

	/** Name of configuration file to use for test (default = epp.config). */
	private static String configFileName = "epp.rootzone.config";

	/** Logging category */
	private static final Logger cat = Logger.getLogger(RZDomainTst.class.getName(),
			EPPCatFactory.getInstance().getFactory());

	/** EPP Session pool associated with test */
	private static EPPSessionPool sessionPool = null;

	/**
	 * Random instance for the generation of unique objects (hosts, IP
	 * addresses, etc.).
	 */
	private Random rd = new Random(System.currentTimeMillis());

	/**
	 * Allocates an <code>NSDomainTst</code> with a logical name. The
	 * constructor will initialize the base class <code>TestCase</code> with
	 * the logical name.
	 * @param name Logical name of the test
	 */
	public RZDomainTst(String name) {
		super(name);
	}

	/**
	 * Unit test of <code>NSDomain.sendCreate</code> command.
	 */
	public void testDomainCreate() {
		printStart("testDomainCreate");

		EPPSession theSession = null;
		EPPResponse theResponse = null;

		try {
			theSession = this.borrowSession();
			RZDomain theDomain = new RZDomain(theSession);

			try {
				System.out
						.println("\n----------------------------------------------------------------");

				String theDomainName = this.makeDomainName();

				System.out.println("domainCreate: Create " + theDomainName
						+ " with no optional attributes");

				theDomain.setTransId("ABC-12345-XYZ");

				theDomain.addDomainName(theDomainName);

				theDomain.setAuthString("ClientX");

				theResponse = theDomain.sendCreate("thx1138");

				// -- Output all of the response attributes
				System.out
						.println("domainCreate: Response = [" + theResponse + "]\n\n");

			} catch (Exception ex) {
				TestUtil.handleException(theSession, ex);
			}

			try {
				System.out
						.println("\n----------------------------------------------------------------");

				theDomain.setTransId("ABC-12345-XYZ");

				String theDomainName = this.makeDomainName();

				System.out.println("domainCreate: Create " + theDomainName
						+ " with all optional attributes");

				theDomain.addDomainName(theDomainName);

				for (int i = 0; i <= 20; i++) {
					theDomain.addHostName(this.makeHostName(theDomainName));
				}

				// Is the contact mapping supported?
				if (EPPFactory.getInstance().hasService(EPPDomainMapFactory.NS_CONTACT)) {
					// Add domain contacts
					theDomain.addContact("SH0000", EPPDomain.CONTACT_ADMINISTRATIVE);

					theDomain.addContact("SH0000", EPPDomain.CONTACT_TECHNICAL);

					theDomain.addContact("SH0000", EPPDomain.CONTACT_BILLING);
				}

				theDomain.setPeriodLength(10);

				theDomain.setPeriodUnit(EPPDomain.PERIOD_YEAR);

				theDomain.setAuthString("ClientX");

				theResponse = theDomain.sendCreate("tk421");

				// -- Output all of the response attributes
				System.out
						.println("domainCreate: Response = [" + theResponse + "]\n\n");
			} catch (Exception ex) {
				TestUtil.handleException(theSession, ex);
			}

		} catch (InvalidateSessionException ex) {
			this.invalidateSession(theSession);
			theSession = null;
		} finally {
			if (theSession != null) this.returnSession(theSession);
		}

		printEnd("testDomainCreate");
	}

	/**
	 * Unit test of <code>NSDomain.sendDomainCheck</code> command.
	 */
	public void testDomainCheck() {
		printStart("testDomainCheck");

		EPPSession theSession = null;
		EPPDomainCheckResp theResponse = null;
		try {
			theSession = this.borrowSession();
			RZDomain theDomain = new RZDomain(theSession);

			try {

				System.out
						.println("\n----------------------------------------------------------------");

				String theDomainName = this.makeDomainName();
				System.out.println("domainCheck: Check single domain name ("
						+ theDomainName + ")");

				theDomain.setTransId("ABC-12345-XYZ");

				theDomain.addDomainName(theDomainName);

				theResponse = theDomain.sendCheck();

				System.out.println("Response Type = " + theResponse.getType());

				System.out.println("Response.TransId.ServerTransId = "
						+ theResponse.getTransId().getServerTransId());

				System.out.println("Response.TransId.ServerTransId = "
						+ theResponse.getTransId().getClientTransId());

				// Output all of the response attributes
				System.out.println("\ndomainCheck: Response = [" + theResponse + "]");

				// For each result
				for (int i = 0; i < theResponse.getCheckResults().size(); i++) {
					EPPDomainCheckResult currResult = (EPPDomainCheckResult) theResponse
							.getCheckResults().elementAt(i);

					if (currResult.isAvailable()) {
						System.out.println("domainCheck: Domain "
								+ currResult.getName() + " is available");
					} else {
						System.out.println("domainCheck: Domain "
								+ currResult.getName() + " is not available");
					}
				}

				this.handleResponse(theResponse);
			} catch (Exception ex) {
				TestUtil.handleException(theSession, ex);
			}

			try {
				// Check multiple domain names
				System.out
						.println("\n----------------------------------------------------------------");
				System.out
						.println("domainCheck: Check multiple domain names (example1.com, example2.com, example3.com)");
				theDomain.setTransId("ABC-12345-XYZ");

				/**
				 * Add example(1-3).com
				 */
				theDomain.addDomainName("example1.com");
				theDomain.addDomainName("example2.com");
				theDomain.addDomainName("example3.com");

				for (int i = 0; i <= 10; i++) {
					theDomain.addDomainName(this.makeDomainName());
				}

				theResponse = theDomain.sendCheck();

				// Output all of the response attributes
				System.out.println("\ndomainCheck: Response = [" + theResponse + "]");
				System.out.println("Client Transaction Id = "
						+ theResponse.getTransId().getClientTransId());
				System.out.println("Server Transaction Id = "
						+ theResponse.getTransId().getServerTransId());

				// For each result
				for (int i = 0; i < theResponse.getCheckResults().size(); i++) {
					EPPDomainCheckResult currResult = (EPPDomainCheckResult) theResponse
							.getCheckResults().elementAt(i);

					if (currResult.isAvailable()) {
						System.out.println("domainCheck: Domain "
								+ currResult.getName() + " is available");
					} else {
						System.out.println("domainCheck: Domain "
								+ currResult.getName() + " is not available");
					}
				}

				this.handleResponse(theResponse);
			} catch (Exception ex) {
				TestUtil.handleException(theSession, ex);
			}

		} catch (InvalidateSessionException ex) {
			this.invalidateSession(theSession);
			theSession = null;
		} finally {
			if (theSession != null) this.returnSession(theSession);
		}

		printEnd("testDomainCheck");
	}

	/**
	 * Unit test of <code>NSDomain.sendDomainInfo</code> command.
	 */
	public void testDomainInfo() {
		printStart("testDomainInfo");

		EPPSession theSession = null;
		EPPDomainInfoResp theResponse = null;
		try {
			theSession = this.borrowSession();
			RZDomain theDomain = new RZDomain(theSession);

			try {
				System.out.println("\ndomainInfo: Standard Domain info");

				theDomain.setTransId("ABC-12345-XYZ");

				theDomain.addDomainName(this.makeDomainName());
				theDomain.setHosts(RZDomain.HOSTS_ALL);

				theResponse = theDomain.sendInfo();

				// -- Output all of the response attributes
				System.out.println("domainInfo: Response = [" + theResponse + "]\n\n");

				// -- Output required response attributes using accessors
				System.out.println("domainInfo: name            = "
						+ theResponse.getName());

				System.out.println("domainInfo: client id       = "
						+ theResponse.getClientId());

				System.out.println("domainInfo: created by      = "
						+ theResponse.getCreatedBy());

				System.out.println("domainInfo: create date     = "
						+ theResponse.getCreatedDate());

				System.out.println("domainInfo: expiration date = "
						+ theResponse.getExpirationDate());

				System.out.println("domainInfo: Registrant      = "
						+ theResponse.getRegistrant());

				/**
				 * Process Contacts
				 */
				if (theResponse.getContacts() != null) {
					for (int i = 0; i < theResponse.getContacts().size(); i++) {
						EPPDomainContact myContact = (EPPDomainContact) theResponse
								.getContacts().elementAt(i);

						System.out.println("Contact Name : " + myContact.getName());

						System.out.println("Contact Type : " + myContact.getType());
					}
				}

				/**
				 * Get AuthInfo
				 */
				if (theResponse.getAuthInfo() != null) {
					System.out.println("Authorization        : "
							+ theResponse.getAuthInfo().getPassword());

					System.out.println("Authorization (Roid) : "
							+ theResponse.getAuthInfo().getRoid());
				}

				/**
				 * Get Hosts
				 */
				if (theResponse.getHosts() != null) {
					for (int i = 0; i < theResponse.getHosts().size(); i++) {
						System.out.println("Host Name : "
								+ theResponse.getHosts().elementAt(i));
					}
				}

				/**
				 * Get Ns
				 */
				if (theResponse.getNses() != null) {
					for (int i = 0; i < theResponse.getNses().size(); i++) {
						System.out.println("Name Server : "
								+ theResponse.getNses().elementAt(i));
					}
				}

				/**
				 * Get Status
				 */
				if (theResponse.getStatuses() != null) {
					for (int i = 0; i < theResponse.getStatuses().size(); i++) {
						EPPDomainStatus myStatus = (EPPDomainStatus) theResponse
								.getStatuses().elementAt(i);

						System.out.println("Lang     : " + myStatus.getLang());

						System.out.println("Status   : " + myStatus.getStatus());
					}
				}

				this.handleResponse(theResponse);

			} catch (Exception ex) {
				TestUtil.handleException(theSession, ex);
			}

		} catch (InvalidateSessionException ex) {
			this.invalidateSession(theSession);
			theSession = null;
		} finally {
			if (theSession != null) this.returnSession(theSession);
		}

		printEnd("testDomainInfo");
	}

	/**
	 * Unit test of <code>NSDomain.sendDelete</code> command.
	 */
	public void testDomainDelete() {
		printStart("testDomainDelete");

		EPPSession theSession = null;
		EPPResponse theResponse = null;
		try {
			theSession = this.borrowSession();
			RZDomain theDomain = new RZDomain(theSession);

			try {
				System.out.println("\ndomainDelete: Domain delete");

				theDomain.setTransId("ABC-12345-XYZ");

				theDomain.addDomainName(this.makeDomainName());

				theResponse = theDomain.sendDelete();

				// -- Output all of the response attributes
				System.out
						.println("domainDelete: Response = [" + theResponse + "]\n\n");

				this.handleResponse(theResponse);

			}

			catch (EPPCommandException ex) {
				TestUtil.handleException(theSession, ex);
			}

		} catch (InvalidateSessionException ex) {
			this.invalidateSession(theSession);
			theSession = null;
		} finally {
			if (theSession != null) this.returnSession(theSession);
		}

		printEnd("testDomainDelete");
	}

	/**
	 * Unit test of <code>NSDomain.sendUpdate</code> command.
	 */
	public void testDomainUpdate() {
		printStart("testDomainUpdate");

		EPPSession theSession = null;
		EPPResponse theResponse = null;
		try {
			theSession = this.borrowSession();
			RZDomain theDomain = new RZDomain(theSession);

			try {

				theDomain.setTransId("ABC-12345-XYZ");

				String theDomainName = this.makeDomainName();

				System.out.println("\ndomainUpdate: Domain " + theDomainName
						+ " update");

				theDomain.addDomainName(theDomainName);

				// Add attributes
				// Is the contact mapping supported?
				if (EPPFactory.getInstance().hasService(EPPDomainMapFactory.NS_CONTACT)) {
					theDomain.setUpdateAttrib(EPPDomain.CONTACT, "SH0000",
							EPPDomain.CONTACT_BILLING, EPPDomain.ADD);
				}

				theDomain.setUpdateAttrib(EPPDomain.HOST, this
						.makeHostName(theDomainName), EPPDomain.ADD);

				theDomain.setUpdateAttrib(EPPDomain.STATUS, new EPPDomainStatus(
						EPPDomain.STATUS_CLIENT_HOLD), EPPDomain.ADD);

				// Remove attributes
				theDomain.setUpdateAttrib(EPPDomain.HOST, this
						.makeHostName(theDomainName), EPPDomain.REMOVE);

				theDomain.setUpdateAttrib(EPPDomain.STATUS, new EPPDomainStatus(
						EPPDomain.STATUS_CLIENT_HOLD), EPPDomain.REMOVE);

				// Is the contact mapping supported?
				if (EPPFactory.getInstance().hasService(EPPDomainMapFactory.NS_CONTACT)) {
					theDomain.setUpdateAttrib(EPPDomain.CONTACT, "SH0000",
							EPPDomain.CONTACT_BILLING, EPPDomain.REMOVE);
				}

				// Update the authInfo value
				theDomain.setAuthString("new-auth-info-123");

				// Execute update
				theResponse = theDomain.sendUpdate();

				// -- Output all of the response attributes
				System.out
						.println("domainUpdate: Response = [" + theResponse + "]\n\n");

				this.handleResponse(theResponse);

			} catch (EPPCommandException ex) {
				TestUtil.handleException(theSession, ex);
			}

		} catch (InvalidateSessionException ex) {
			this.invalidateSession(theSession);
			theSession = null;
		} finally {
			if (theSession != null) this.returnSession(theSession);
		}

		printEnd("testDomainUpdate");
	}

	/**
	 * Unit test of <code>NSDomain.sendCreate</code> command with IDN tag
	 * extension.
	 */
	public void testDomainIDNCreate() {
		printStart("testDomainIDNCreate");

		EPPSession theSession = null;
		EPPDomainCreateResp theResponse = null;

		try {
			theSession = this.borrowSession();
			RZDomain theDomain = new RZDomain(theSession);

			try {
				System.out
						.println("\n----------------------------------------------------------------");

				String theDomainName = this.makeDomainName();

				System.out.println("domainCreate: Create " + theDomainName
						+ " with IDN tag");

				theDomain.setTransId("ABC-12345-XYZ");

				theDomain.addDomainName(theDomainName);

				theDomain.setAuthString("ClientX");

				theDomain.setIDNLangTag("en");

				theResponse = theDomain.sendCreate();

				// -- Output all of the response attributes
				System.out
						.println("domainCreate: Response = [" + theResponse + "]\n\n");

			} catch (EPPCommandException ex) {
				TestUtil.handleException(theSession, ex);
			}

		} catch (InvalidateSessionException ex) {
			this.invalidateSession(theSession);
			theSession = null;
		} finally {
			if (theSession != null) this.returnSession(theSession);
		}

		printEnd("testDomainIDNCreate");
	}

	/**
	 * Unit test of <code>EPPSession.endSession</code>. One session in the
	 * session pool wil be ended.
	 */
	public void testEndSession() {
		printStart("testEndSession");

		EPPSession theSession = null;
		try {
			theSession = this.borrowSession();
			sessionPool.invalidateObject(theSession);
			theSession = null;
		} catch (Exception ex) {
			ex.printStackTrace();
			Assert.fail("testEndSession(): Exception invalidating session: " + ex);
		} finally {
			if (theSession != null) this.returnSession(theSession);
		}

		printEnd("testEndSession");
	}

	// End NSDomainTst.endSession()

	/**
	 * JUNIT <code>setUp</code> method
	 */
	protected void setUp() {

	}

	// End NSDomainTst.setUp();

	/**
	 * JUNIT <code>tearDown</code>, which currently does nothing.
	 */
	protected void tearDown() {}

	// End NSDomainTst.tearDown();

	/**
	 * JUNIT <code>suite</code> static method, which returns the tests
	 * associated with <code>NSDomainTst</code>.
	 * @return DOCUMENT ME!
	 */
	public static Test suite() {
		return new NSDomainTstSetup(new TestSuite(RZDomainTst.class));
	}

	// End NSDomainTst.suite()

	/**
	 * Setup framework from running NSDomainTst tests.
	 */
	private static class NSDomainTstSetup extends TestSetup {

		/**
		 * Creates setup instance for passed in tests.
		 * @param aTest Tests to execute
		 */
		public NSDomainTstSetup(Test aTest) {
			super(aTest);
		}

		/**
		 * Setup framework for running NSDomainTst tests.
		 */
		protected void setUp() throws Exception {
			super.setUp();

			String theConfigFileName = System.getProperty("EPP.ConfigFile");
			if (theConfigFileName != null) configFileName = theConfigFileName;

			try {
				app.initialize(configFileName);
			} catch (EPPCommandException e) {
				e.printStackTrace();
				Assert.fail("Error initializing the EPP Application: " + e);
			}

			// Initialize the session pool
			try {
				sessionPool = EPPSessionPool.getInstance();
				sessionPool.init();
			} catch (Exception ex) {
				ex.printStackTrace();
				Assert.fail("Error initializing the session pool: " + ex);
			}

		}

		/**
		 * Tear down framework from running NSDomainTst tests.
		 */
		protected void tearDown() throws Exception {
			super.tearDown();
		}
	}

	/**
	 * Unit test main, which accepts the following system property options: <br>
	 * <ul>
	 * <li>iterations Number of unit test iterations to run</li>
	 * <li>validate Turn XML validation on (<code>true</code>) or off (
	 * <code>false</code>). If validate is not specified, validation will be
	 * off.</li>
	 * </ul>
	 * @param args DOCUMENT ME!
	 */
	public static void main(String[] args) {
		// Override the default configuration file name?
		if (args.length > 0) {
			configFileName = args[0];
		}

		// Number of Threads
		int numThreads = 1;
		String threadsStr = System.getProperty("threads");

		if (threadsStr != null) {
			numThreads = Integer.parseInt(threadsStr);
		}

		// Run test suite in multiple threads?
		if (numThreads > 1) {
			// Spawn each thread passing in the Test Suite
			for (int i = 0; i < numThreads; i++) {
				TestThread thread = new TestThread("NSDomainTst Thread " + i,
						RZDomainTst.suite());
				thread.start();
			}
		} else { // Single threaded mode.
			junit.textui.TestRunner.run(RZDomainTst.suite());
		}

		try {
			app.endApplication();
		} catch (EPPCommandException e) {
			e.printStackTrace();
			Assert.fail("Error ending the EPP Application: " + e);
		}
	}

	// End NSDomainTst.main(String [])

	/**
	 * Print the start of a test with the <code>Thread</code> name if the
	 * current thread is a <code>TestThread</code>.
	 * @param aTest name for the test
	 */
	public static void printStart(String aTest) {
		if (Thread.currentThread() instanceof TestThread) {
			System.out.print(Thread.currentThread().getName() + ": ");
			cat.info(Thread.currentThread().getName() + ": " + aTest + " Start");
		}

		System.out.println("Start of " + aTest);
		System.out
				.println("****************************************************************\n");
	}

	// End NSDomainTst.testStart(String)

	/**
	 * Print the end of a test with the <code>Thread</code> name if the
	 * current thread is a <code>TestThread</code>.
	 * @param aTest name for the test
	 */
	public static void printEnd(String aTest) {
		System.out
				.println("****************************************************************");

		if (Thread.currentThread() instanceof TestThread) {
			System.out.print(Thread.currentThread().getName() + ": ");
			cat.info(Thread.currentThread().getName() + ": " + aTest + " End");
		}

		System.out.println("End of " + aTest);
		System.out.println("\n");
	}

	// End NSDomainTst.testEnd(String)

	/**
	 * Utility method to borrow a session from the session pool. All exceptions
	 * will result in the test failing. This method should only be used for
	 * positive session pool tests.
	 * @return Session from the session pool
	 */
	private EPPSession borrowSession() {
		EPPSession theSession = null;
		try {
			theSession = sessionPool.borrowObject();
		} catch (Exception ex) {
			ex.printStackTrace();
			Assert.fail("borrowSession(): Exception borrowing session: " + ex);
		}

		return theSession;
	}

	/**
	 * Utility method to return a session to the session pool. This should be
	 * placed in a finally block. All exceptions will result in the test
	 * failing.
	 * @param aSession Session to return to the pool
	 */
	private void returnSession(EPPSession aSession) {
		try {
			if (aSession != null) sessionPool.returnObject(aSession);
		} catch (Exception ex) {
			ex.printStackTrace();
			Assert.fail("returnSession(): Exception returning session: " + ex);
		}
	}

	/**
	 * Utility method to invalidate a session in the session pool. This should
	 * be placed in an exception block.
	 * @param aSession Session to invalidate in the pool
	 */
	private void invalidateSession(EPPSession aSession) {
		try {
			if (aSession != null) sessionPool.invalidateObject(aSession);
		} catch (Exception ex) {
			ex.printStackTrace();
			Assert.fail("invalidateSession(): Exception invalidating session: " + ex);
		}
	}

	/**
	 * Handle a response by printing out the result details.
	 * @param aResponse the response to handle
	 */
	private void handleResponse(EPPResponse aResponse) {

		for (int i = 0; i < aResponse.getResults().size(); i++) {
			EPPResult theResult = (EPPResult) aResponse.getResults().elementAt(i);

			System.out.println("Result Code    : " + theResult.getCode());
			System.out.println("Result Message : " + theResult.getMessage());
			System.out.println("Result Lang    : " + theResult.getLang());

			if (theResult.isSuccess()) {
				System.out.println("Command Passed ");
			} else {
				System.out.println("Command Failed ");
			}

			if (theResult.getAllValues() != null) {
				for (int k = 0; k < theResult.getAllValues().size(); k++) {
					System.out.println("Result Values  : "
							+ theResult.getAllValues().elementAt(k));
				}
			}
		}
	} // End handleResponse(EPPResponse)

	/**
	 * This method tries to generate a unique String as Domain Name and Name
	 * Server
	 * @return Unique domain name
	 */
	public String makeDomainName() {
		long tm = System.currentTimeMillis();

		return new String(Thread.currentThread()
				+ String.valueOf(tm + rd.nextInt(12)).substring(10) + ".com");
	}

	/**
	 * Makes a unique IP address based off of the current time.
	 * @return Unique IP address <code>String</code>
	 */
	public String makeIP() {
		long tm = System.currentTimeMillis();

		return new String(String.valueOf(tm + rd.nextInt(50)).substring(10) + "."
				+ String.valueOf(tm + rd.nextInt(50)).substring(10) + "."
				+ String.valueOf(tm + rd.nextInt(50)).substring(10) + "."
				+ String.valueOf(tm + rd.nextInt(50)).substring(10));
	}

	/**
	 * Makes a unique host name for a domain using the current time.
	 * @param newDomainName DOCUMENT ME!
	 * @return Unique host name <code>String</code>
	 */
	public String makeHostName(String newDomainName) {
		long tm = System.currentTimeMillis();

		return new String(String.valueOf(tm + rd.nextInt(10)).substring(10) + "."
				+ newDomainName);
	}

	/**
	 * Makes a unique contact name using the current time.
	 * @return Unique contact name <code>String</code>
	 */
	public String makeContactName() {
		long tm = System.currentTimeMillis();

		return new String("Con" + String.valueOf(tm + rd.nextInt(5)).substring(7));
	}

} // End class NSDomainTst
