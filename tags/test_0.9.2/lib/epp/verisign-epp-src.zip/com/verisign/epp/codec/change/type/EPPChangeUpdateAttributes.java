/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change.type;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.verisign.epp.codec.change.EPPChangeMapFactory;
import com.verisign.epp.codec.change.util.TextUtil;
import com.verisign.epp.codec.change.util.TypeUtil;
import com.verisign.epp.codec.gen.EPPCodecComponent;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPUtil;
import com.verisign.epp.util.EqualityUtil;

/**
 * Encapsulates an Change:Action attached to a Change:Request.
 * @author jcolosi
 */
public class EPPChangeUpdateAttributes implements EPPCodecComponent {
	static public final String ELM_NAME = "change:upAttrs";

	private String priority = null;
	private List categories = null;
	private String description = null;

	public EPPChangeUpdateAttributes() {}

	public EPPChangeUpdateAttributes(Element element) throws EPPDecodeException {
		decode(element);
	}

	public EPPChangeUpdateAttributes(String priority, List categories,
			String description) {
		setPriority(priority);
		setCategories(categories);
		setDescription(description);
	}

	public EPPChangeUpdateAttributes(String priority, String category,
			String description) {
		setPriority(priority);
		addCategory(category);
		setDescription(description);
	}

	public void addCategory(String category) {
		if (category != null) {
			if (categories == null) categories = new ArrayList();
			categories.add(category);
		}
	}

	public void clearCategories() {
		this.categories = null;
	}

	public Object clone() throws CloneNotSupportedException {
		return (EPPChangeUpdateAttributes) super.clone();
	}

	/**
	 * Decode the EPPChangeAction attributes from the DOM Element tree.
	 * @param aElement - Root DOM Element to decode
	 * @exception EPPDecodeException Unable to decode aElement
	 * @throws ParseException
	 */
	public void decode(Element aElement) throws EPPDecodeException {
		/**
		 * LOGIC: Decode nested elements - because I am so clever, the schema
		 * requires that at least one of these items is present. :)
		 */
		NodeList nodes = aElement.getChildNodes();
		if (nodes != null) {
			int size = nodes.getLength();
			for (int i = 0; i < size; i++) {
				Node node = nodes.item(i);
				if (node instanceof Element) {
					String name = node.getNodeName();
					if (name.equals(TypeUtil.ELM_PRIORITY)) {
						setPriority(EPPUtil.getTextContent(node));
					} else if (name.equals(TypeUtil.ELM_CATEGORY)) {
						addCategory(EPPUtil.getTextContent(node));
					} else if (name.equals(TypeUtil.ELM_DESCRIPTION)) {
						setDescription(EPPUtil.getTextContent(node));
					}
				}
			}
		}

		/**
		 * LOGIC: No one attribute is required so there are no assertions here.
		 * Let the schema assert that 1 of these exists.
		 */
	}

	/**
	 * Encode a DOM Element tree from the attributes of the EPPChangeTld
	 * instance.
	 * @param aDocument - DOM Document that is being built. Used as an Element
	 *            factory.
	 * @return Element - Root DOM Element representing the EPPChangeTld
	 *         instance.
	 * @exception EPPEncodeException - Unable to encode EPPChangeTld instance.
	 */
	public Element encode(Document aDocument) throws EPPEncodeException {
		Element root = aDocument.createElementNS(EPPChangeMapFactory.NS, ELM_NAME);

		/**
		 * LOGIC: No one attribute is required so there are no assertions here.
		 * Let the schema assert that 1 of these exists.
		 */
		EPPUtil.encodeString(aDocument, root, priority, EPPChangeMapFactory.NS,
				TypeUtil.ELM_PRIORITY);
		EPPUtil.encodeList(aDocument, root, categories, EPPChangeMapFactory.NS,
				TypeUtil.ELM_CATEGORY);
		EPPUtil.encodeString(aDocument, root, description, EPPChangeMapFactory.NS,
				TypeUtil.ELM_DESCRIPTION);

		return root;
	}

	/**
	 * Compare an instance of <code>EPPChangeUpdateAttributes</code> with this
	 * instance
	 */
	public boolean equals(Object o) {
		if ((o == null) || (!o.getClass().equals(this.getClass()))) return false;
		EPPChangeUpdateAttributes other = (EPPChangeUpdateAttributes) o;
		return EqualityUtil.equals(this.priority, other.priority)
				&& EqualityUtil.equals(this.categories, other.categories)
				&& EqualityUtil.equals(this.description, other.description);
	}

	public List getCategories() {
		return categories;
	}

	public String getDescription() {
		return description;
	}

	public String getPriority() {
		return priority;
	}

	public void setCategories(List categories) {
		this.categories = categories;
	}

	public void setDescription(String description) {
		this.description = TextUtil.normalize(description);
	}

	public void setPriority(String priority) {
		this.priority = TextUtil.normalize(priority);
	}

	/**
	 * Implementation of <code>Object.toString</code>, which will result in
	 * an indented XML <code>String</code> representation of the concrete
	 * <code>EPPCodecComponent</code>.
	 * @return Indented XML <code>String</code> if successful;
	 *         <code>ERROR</code> otherwise.
	 */
	public String toString() {
		return EPPUtil.toString(this);
	}
}