/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.verisign.epp.codec.change.type.EPPChangeUpdateAttributes;
import com.verisign.epp.codec.change.util.ExceptionUtil;
import com.verisign.epp.codec.change.util.TextUtil;
import com.verisign.epp.codec.change.util.TypeUtil;
import com.verisign.epp.codec.gen.EPPCodec;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPUpdateCmd;
import com.verisign.epp.codec.gen.EPPUtil;
import com.verisign.epp.util.EqualityUtil;

/**
 * Represents an EPP &lt;change:update&gt; command that is used to modify an
 * existing EPP Change Request object. The &lt;change:update&gt; element MAY
 * contain the following child elements: <br>
 * <br>
 * <ul>
 * <li>A &lt;change:upAttrs&gt; element that contains the Change Request
 * attributes for modification. Use <code>getAttributes</code> and
 * <code>setAttributes</code> to get and set the element.</li>
 * <p>
 * <center><bold><font size=5>or</font></bold></center>
 * <li>An empty &lt;change:clear&gt; element. Use <code>isClear</code> and
 * <code>setClear</code> to get and set the element.</li>
 * <p>
 * <center><bold><font size=5>or</font></bold></center>
 * <li>An empty &lt;change:submit&gt; element. Use <code>isSubmit</code> and
 * <code>setSubmit</code> to get and set the element.</li>
 * </ul>
 * <br>
 * @see com.verisign.epp.codec.change.EPPChangeUpdateResp
 * @author jcolosi
 */
public class EPPChangeUpdateCmd extends EPPUpdateCmd {

	static final String ELM_NAME = "change:update";

	private EPPChangeUpdateAttributes attributes = null;
	private boolean clear = false;
	private boolean submit = false;
	private String requestId = null;

	public EPPChangeUpdateCmd() {
		this(null);
	}

	public EPPChangeUpdateCmd(String aTransId) {
		super(aTransId);
	}

	public EPPChangeUpdateCmd(String aTransId, String requestId) {
		super(aTransId);
		setRequestId(requestId);
	}

	/**
	 * Clone <code>EPPChangeUpdateCmd</code>.
	 * @return clone of <code>EPPChangeUpdateCmd</code>
	 * @exception CloneNotSupportedException standard Object.clone exception
	 */
	public Object clone() throws CloneNotSupportedException {
		return (EPPChangeUpdateCmd) super.clone();
	}

	/**
	 * Compare an instance of <code>EPPChangeUpdateCmd</code> with this
	 * instance
	 */
	public boolean equals(Object o) {
		if ((o == null) || (!o.getClass().equals(this.getClass()))) return false;
		EPPChangeUpdateCmd other = (EPPChangeUpdateCmd) o;

		return EqualityUtil.equals(this.requestId, other.requestId)
				&& EqualityUtil.equals(this.attributes, other.attributes)
				&& this.clear == other.clear && this.submit == other.submit;
	}

	public EPPChangeUpdateAttributes getAttributes() {
		return attributes;
	}

	/**
	 * Gets the EPP command Namespace associated with
	 * <code>EPPChangeUpdateCmd</code>.
	 * @return <code>EPPChangeMapFactory.NS</code>
	 */
	public String getNamespace() {
		return EPPChangeMapFactory.NS;
	}

	public String getRequestId() {
		return requestId;
	}

	public boolean isClear() {
		return clear;
	}

	public boolean isSubmit() {
		return submit;
	}

	public void setAttributes(EPPChangeUpdateAttributes attributes) {
		this.attributes = attributes;
	}

	public void setClear(boolean clear) {
		this.clear = clear;
	}

	public void setRequestId(String requestId) {
		this.requestId = TextUtil.normalize(requestId);
	}

	public void setSubmit(boolean submit) {
		this.submit = submit;
	}

	/**
	 * Implementation of <code>Object.toString</code>, which will result in
	 * an indented XML <code>String</code> representation of the concrete
	 * <code>EPPCodecComponent</code>.
	 * @return Indented XML <code>String</code> if successful;
	 *         <code>ERROR</code> otherwise.
	 */
	public String toString() {
		return EPPUtil.toString(this);
	}

	/**
	 * Decode the <code>EPPChangeUpdateCmd</code> attributes from the aElement
	 * DOM Element tree.
	 * @param aElement Root DOM Element to decode
	 *            <code>EPPChangeUpdateCmd</code> from.
	 * @exception EPPDecodeException Unable to decode aElement
	 */
	protected void doDecode(Element aElement) throws EPPDecodeException {
		/**
		 * LOGIC: Decode nested elements
		 */
		NodeList nodes = aElement.getChildNodes();
		if (nodes != null) {
			int size = nodes.getLength();
			for (int i = 0; i < size; i++) {
				Node node = nodes.item(i);
				if (node instanceof Element) {
					String name = node.getNodeName();
					if (name.equals(TypeUtil.ELM_REQUESTID)) {
						setRequestId(EPPUtil.getTextContent(node));
					} else if (name.equals(EPPChangeUpdateAttributes.ELM_NAME)) {
						setAttributes(new EPPChangeUpdateAttributes((Element) node));
					} else if (name.equals(TypeUtil.ELM_CLEAR)) setClear(true);
					else if (name.equals(TypeUtil.ELM_SUBMIT)) setSubmit(true);
				}
			}
		}

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForDecode(requestId, TypeUtil.ELM_REQUESTID);
	}

	/**
	 * Encode a DOM Element tree from the attributes of the
	 * <code>EPPChangeUpdateCmd</code> instance.
	 * @param aDocument DOM Document that is being built. Used as an Element
	 *            factory.
	 * @return Root DOM Element representing the <code>EPPChangeUpdateCmd</code>
	 *         instance.
	 * @exception EPPEncodeException Unable to encode
	 *                <code>EPPChangeUpdateCmd</code> instance.
	 */
	protected Element doEncode(Document aDocument) throws EPPEncodeException {
		Element root = aDocument.createElementNS(EPPChangeMapFactory.NS, ELM_NAME);
		root.setAttribute("xmlns:change", EPPChangeMapFactory.NS);
		root.setAttributeNS(EPPCodec.NS_XSI, "xsi:schemaLocation",
				EPPChangeMapFactory.NS_SCHEMA);

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForEncode(requestId, TypeUtil.ELM_REQUESTID);

		EPPUtil.encodeString(aDocument, root, requestId, EPPChangeMapFactory.NS,
				TypeUtil.ELM_REQUESTID);
		if (attributes != null) EPPUtil.encodeComp(aDocument, root, attributes);
		if (isClear()) root.appendChild(aDocument.createElement(TypeUtil.ELM_CLEAR));
		if (isSubmit()) root.appendChild(aDocument.createElement(TypeUtil.ELM_SUBMIT));

		return root;
	}
}