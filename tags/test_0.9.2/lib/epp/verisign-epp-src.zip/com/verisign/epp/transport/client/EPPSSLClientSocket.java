/***********************************************************
Copyright (C) 2004 VeriSign, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

http://www.verisign.com/nds/naming/namestore/techdocs.html
***********************************************************/

/**
 * This Class primarily utilizes Sun's JSSE 1.0.2 reference implementation.
 * This reference implementation is simply a proof-of-concept. It is used to
 * demonstrate that the specification is implementable and compatible tests
 * can be written against it.
 */
package com.verisign.epp.transport.client;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import org.apache.log4j.Logger;

import com.verisign.epp.transport.EPPClientCon;
import com.verisign.epp.transport.EPPConException;
import com.verisign.epp.util.EPPCatFactory;
import com.verisign.epp.util.EPPEnv;
import com.verisign.epp.util.EPPEnvException;


/**
 * This is Secure Socket Connection this class establishes the connections and
 * forwards the InputStream and OutputStream. This Class primarily utilizes
 * Sun's JSSE 1.0.2 reference implementation. This reference implementation is
 * proof-of-concept. It is used to demonstrate that the specification is
 * implementable and compatible tests can be written against it.
 */
public class EPPSSLClientSocket implements EPPClientCon {
	/** Log4j category for logging */
	private static Logger cat =
		Logger.getLogger(
						 EPPSSLClientSocket.class.getName(),
						 EPPCatFactory.getInstance().getFactory());

	/** This attribute maintains an instance of the socket connection. */
	private SSLSocket mySocket = null;

	/**
	 * This attribute contains and isntance of OutputStream Associated with
	 * Socket.
	 */
	private OutputStream myOutputStream = null;

	/**
	 * This attribute is an isntance of InputStream associated with the Socket
	 * connection
	 */
	private InputStream myInputStream = null;

	/** This attribute contains Host Name */
	private String myHostName = null;

	/** This attribute contains port number */
	private int myPortNumber = 0;

	/** This attribute contains Client Host Name */
	private String myClientHostName = null;

	/** contains status of connection */
	private boolean isConnected = true;

	/** DOCUMENT ME! */
	private int myConTimeout = 50;

	/**
	 * SSL context information
	 */
	private EPPSSLContext sslContext = null;
	
	
	/**
	 * Pre-condition the util.Env provide the properties
	 *
	 * @throws EPPConException DOCUMENT ME!
	 */
	public EPPSSLClientSocket() throws EPPConException {
		
		/*
		 * properties are set via util.Env
		 */
		try {
			myHostName		 = EPPEnv.getServerName();
			myPortNumber     = EPPEnv.getServerPort();
			myConTimeout     = EPPEnv.getConTimeOut();
			myClientHostName = EPPEnv.getClientHost();
		}
		 catch (EPPEnvException myException) {
			/**
			 * Log the Error
			 */
			cat.error(
					  "Connection Failed Due to : " + myException.getMessage(),
					  myException);

			throw new EPPConException("Connection Failed Due to : "
									  + myException.getMessage());
		}
	}

	/**
	 * Initializes an SSL connection to the host and port defined by the 
	 * server name and the server port properties of <code>EPPEnv</code>.
	 *
	 * @exception EPPConException Error initializing the connection.
	 */
	public void initialize() throws EPPConException {
		cat.debug("Starting EPPSSLClientSocket.initialize()");
		
		if (this.sslContext == null) {
			// Ensure that EPPSSLImpl is initialized
			EPPSSLImpl.initialize();
			this.sslContext = EPPSSLImpl.getEPPSSLContext();
		}

		// Get the SSLSocketFactory from EPPSSLImpl
		SSLSocketFactory mySSLSocketFactory = this.sslContext.getSSLSocketFactory();

		// Create SSLSocket from SSLSocketFactory
		try {
			
			if (this.myClientHostName == null) {
				cat.debug("EPPSSLClientSocket.initialize(): Connecting to server host = " + 
						myHostName + ", server port = " + myPortNumber);
				mySocket =
					(SSLSocket) mySSLSocketFactory.createSocket(
																myHostName,
																myPortNumber);
			}
			else {
				cat.debug("EPPSSLClientSocket.initialize(): Connecting to server host = " + 
						myHostName + ", server port = " + myPortNumber + 
						" from client host = " + myClientHostName);
				InetAddress theClientAddress = InetAddress.getByName(this.myClientHostName);
				
				mySocket =
					(SSLSocket) mySSLSocketFactory.createSocket(
																myHostName,
																myPortNumber,
																theClientAddress,
																0);				
			}
			
			// Log the SSL supported protocols and cipher suites?
			if (cat.isDebugEnabled()) {
				cat.debug("EPPSSLClientSocket.initialize(): Supported Protocols = [" +
						this.getSSLPropertyListString(mySocket.getSupportedProtocols()) + "], Supported Cipher Suites = [" + 
						this.getSSLPropertyListString(mySocket.getSupportedCipherSuites()) + "]");
			}
			
			// Set additional SSL handshake properties (enabled protocols and enabled cipher suites)
			if (this.sslContext.hasSSLEnabledProtocols()) {
				cat.debug("EPPSSLClientSocket.initialize(): Enabled Protocols = [" +
						this.getSSLPropertyListString(this.sslContext.getSSLEnabledProtocols()) + "]");
				mySocket.setEnabledProtocols(this.sslContext.getSSLEnabledProtocols());
			}
			else {
				cat.debug("EPPSSLClientSocket.initialize(): Enabled Protocols NOT specified, using providers default");				
			}
			
			if (this.sslContext.hasSSLEnabledCipherSuites()) {
				cat.debug("EPPSSLClientSocket.initialize(): Enabled Cipher Suites = [" +
						this.getSSLPropertyListString(this.sslContext.getSSLEnabledCipherSuites()) + "]");
				mySocket.setEnabledCipherSuites(this.sslContext.getSSLEnabledCipherSuites());
			}
			else {
				cat.debug("EPPSSLClientSocket.initialize(): Enabled Cipher Suites NOT specified, using providers default");				
			}
			
			
			mySocket.setSoTimeout(myConTimeout);
		}
		 catch (IOException myException) {
			cat.error("Could not create an SSLSocket: ", myException);
			throw new EPPConException("Could not create an SSLSocket: "
									  + myException.getMessage());
		}

		cat.info("EPPSSLClientSocket.initialize(): SSL startHandshake");

		/*
		 * Before any application data is sent or received, the
		 * SSL socket will do SSL handshaking first to set up
		 * the security attributes.
		 */
		try {
			mySocket.startHandshake();
		}
		 catch (IOException myException) {
			/**
			 * Log the Error
			 */
			cat.error(
					  "Failed When Handshake : " + myException.getMessage(),
					  myException);

			throw new EPPConException("Failed When HandShake : "
									  + myException.getMessage());
		}

		/**
		 * get InputOutput
		 */
		try {
			myInputStream	   = mySocket.getInputStream();
			myOutputStream     = mySocket.getOutputStream();
		}
		 catch (IOException myException) {
			/**
			 * Log the Error
			 */
			cat.error("IO Exception when Initializing SSL ", myException);
			throw new EPPConException("IO Exception when Initializing SSL "
									  + myException.getMessage());
		}

		isConnected = true;

		/**
		 * Log Debug Message
		 */
		cat.debug("Ending EPPSSLClientSocket.initialize()");

		return;
	}
	
	/**
	 * Initializes a SSL connection to a specific host and port.  There remainder of the 
	 * connection settings is derived from the <code>EPPEnv</code> properties.
	 * 
	 * @param aHostName Host name or IP address of host to connect to
	 * @param aPortNumber Port number to connect to
	 * @param aSSLContext Optional specific SSL context to use
	 * 
	 * @exception EPPConException Error initializing the connection.
	 */
	public void initialize(String aHostName, int aPortNumber, EPPSSLContext aSSLContext)
			throws EPPConException {
		this.myHostName = aHostName;
		this.myPortNumber = aPortNumber;
		this.sslContext = aSSLContext;
		
		this.initialize();
	}
	
	
	/**
	 * Initializes a SSL connection to a specific host and port.  There remainder of the 
	 * connection settings is derived from the <code>EPPEnv</code> properties.
	 * 
	 * @param aHostName Host name or IP address of host to connect to
	 * @param aPortNumber Port number to connect to
	 * @param aClientHostName Host name or IP address to connect from
	 * @param aSSLContext Optional specific SSL context to use
	 * 
	 * @exception EPPConException Error initializing the connection.
	 */
	public void initialize(String aHostName, int aPortNumber, String aClientHostName, EPPSSLContext aSSLContext)
			throws EPPConException {
		this.myHostName = aHostName;
		this.myPortNumber = aPortNumber;
		this.myClientHostName = aClientHostName;
		this.sslContext = aSSLContext;
		
		this.initialize();
	}
	

	/**
	 * DOCUMENT ME!
	 *
	 * @return InputStream
	 *
	 * @exception EPPConException
	 */
	public InputStream getInputStream() throws EPPConException {
		if (myInputStream == null) {
			/**
			 * Log the Error
			 */
			cat.error("Bad Connection");
			throw new EPPConException("Bad Connection.");
		}

		return myInputStream;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @return OutputStream
	 *
	 * @exception EPPConException
	 */
	public OutputStream getOutputStream() throws EPPConException {
		if (myOutputStream == null) {
			/**
			 * Log the Error
			 */
			cat.error("EPPSSLClientSocket.getOutputStream() : Bad Connection");
			throw new EPPConException("EPPSSLClientSocket.getOutputStream() : Bad Connection");
		}

		return myOutputStream;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param newInputStream
	 */
	private void setInputStream(InputStream newInputStream) {
		myInputStream = newInputStream;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param newOutputStream
	 */
	private void setOutputStream(OutputStream newOutputStream) {
		myOutputStream = newOutputStream;
	}

	/**
	 * Access method for the mySocket property.
	 *
	 * @return the current value of the mySocket property
	 */
	private SSLSocket getSocket() {
		return mySocket;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @param newSocket the new value of the mySocket property
	 */
	private void setMySocket(SSLSocket newSocket) {
		mySocket = (SSLSocket) newSocket;
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @exception EPPConException Closes this socket connection
	 */
	public void close() throws EPPConException {
		/**
		 * Log Debug Message
		 */
		cat.debug("EPPSSLClientSocket.close(): Starting the Method");

		if (!isConnected) {
			return;
		}

		/*
		 * Check to see if the connection
		 * is valid
		 */
		try {
			if (myOutputStream != null) {
				myOutputStream.close();
				myOutputStream = null;
			}

			if (myInputStream != null) {
				myInputStream.close();
				myInputStream = null;
			}
		}
		 catch (IOException myException) {
			/**
			 * Log the Error
			 */
			cat.error(
					  "When Closing Connection : " + myException.getMessage(),
					  myException);

			throw new EPPConException("When Closing Conection : "
									  + myException.getMessage());
		}
		 catch (SecurityException myException) {
			cat.error(
					  "EPPSSLClientSocket.close() : When Closing Conection : SecurityException ",
					  myException);

			// ignore this one
		}
		 finally {
			isConnected = false;
		}

		/**
		 * Log Debug Message
		 */
		cat.debug("EPPSSLClientSocket.close(): Ending the Method");

		return;
	}
	
	/**
	 * Gets an SSL property list as a string for logging purposes. 
	 * Examples of SSL property lists include supported protocols,
	 * enabled protocols, supported cipher suites, and enabled cipher suites.
	 * 
	 * @param aList <code>Array</code> of <code>String</code>'s.
	 * @return Space delimeted <code>String</code> representing the property list if 
	 * <code>aList</code> is not <code>null</code>;<code>null</code> otherwise
	 */
	private String getSSLPropertyListString(String aList[]) {
		if (aList == null) {
			return null;
		}
		
		String theStr = "";
		for (int i = 0; i < aList.length; i++) {
			if (i > 0) {
				theStr += " ";
			}
			theStr += aList[i];
		}
		
		return theStr;
	}
	
}
