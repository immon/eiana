/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

 http://www.verisign.com/nds/naming/changeext/techdocs.html
 ***********************************************************/

package com.verisign.epp.codec.changeext;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.verisign.epp.codec.gen.EPPCodec;
import com.verisign.epp.codec.gen.EPPCodecComponent;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPUtil;
import com.verisign.epp.util.EqualityUtil;

/**
 * Change &ltchangeExt&gt extension, which allows for a client to provide a
 * target sub-product identifier to specify the locus of operation for the
 * accompanying command. <br>
 * <br>
 * @author $Author: jim $
 * @version $Revision: 1.4 $
 */
public class EPPChangeExt implements EPPCodecComponent {
	/** XML root tag for <code>EPPChangeExtChangeExt</code>. */
	public static final String ELM_NAME = "changeExt:changeExt";

	/** XML tag name for the <code>_subProductID</code> attribute. */
	private static final String ELM_REQUESTID = "changeExt:requestID";

	/** Sub-Product Identifier. */
	private String requestId;

	/**
	 * Default constructor for <code>EPPChangeExtChangeExt</code>.
	 */
	public EPPChangeExt() {
		requestId = null;
	}

	/**
	 * Constructor for <code>EPPChangeExtChangeExt</code> that takes the
	 * Change Request identifier.
	 * @param arequestID Change Request identifier
	 */
	public EPPChangeExt(String arequestID) {
		requestId = arequestID;
	}

	/**
	 * Gets the Change Destination Registry Identifier.
	 * @return Registry identifier if defined; <code>null</code> otherwise.
	 */
	public String getRequestId() {
		return requestId;
	}

	/**
	 * Sets the Change Identifier.
	 * @param aRequestId Change Request Identifier
	 */
	public void setRequestId(String aRequestId) {
		requestId = aRequestId;
	}

	/**
	 * encode instance into a DOM element tree. A DOM Document is passed as an
	 * argument and functions as a factory for DOM objects. The root element
	 * associated with the instance is created and each instance attributeis
	 * appended as a child node.
	 * @param aDocument DOM Document, which acts is an Element factory
	 * @return Element Root element associated with the object
	 * @exception EPPEncodeException Error encoding <code>EPPChangeExt</code>
	 */
	public Element encode(Document aDocument) throws EPPEncodeException {
		if (requestId == null) { throw new EPPEncodeException(
				"required requestId attribute is not set"); }

		Element root = aDocument.createElementNS(EPPChangeExtFactory.NS, ELM_NAME);
		root.setAttribute("xmlns:changeExt", EPPChangeExtFactory.NS);
		root.setAttributeNS(EPPCodec.NS_XSI, "xsi:schemaLocation",
				EPPChangeExtFactory.NS_SCHEMA);

		EPPUtil.encodeString(aDocument, root, requestId, EPPChangeExtFactory.NS,
				ELM_REQUESTID);

		return root;
	}

	/**
	 * decode a DOM element tree to initialize the instance attributes. The
	 * <code>aElement</code> argument represents the root DOM element and is
	 * used to traverse the DOM nodes for instance attribute values.
	 * @param aElement <code>Element</code> to decode
	 * @exception EPPDecodeException Error decoding <code>Element</code>
	 */
	public void decode(Element aElement) throws EPPDecodeException {
		requestId = EPPUtil.decodeString(aElement, EPPChangeExtFactory.NS,
				ELM_REQUESTID);
	}

	/**
	 * clone an <code>EPPCodecComponent</code>.
	 * @return clone of concrete <code>EPPChangeExtChangeExt</code>
	 * @exception CloneNotSupportedException standard Object.clone exception
	 */
	public Object clone() throws CloneNotSupportedException {
		EPPChangeExt clone = (EPPChangeExt) super.clone();
		return clone;
	}

	/**
	 * Implementation of <code>Object.toString</code>, which will result in
	 * an indented XML <code>String</code> representation of the concrete
	 * <code>EPPCodecComponent</code>.
	 * @return Indented XML <code>String</code> if successful;
	 *         <code>ERROR</code> otherwise.
	 */
	public String toString() {
		return EPPUtil.toString(this);
	}

	/**
	 * Compare an instance of <code>EPPChangeExtChangeExt</code> with this
	 * instance.
	 * @param aObject Object to compare with.
	 * @return <code>true</code> if equal; <code>false</code> otherwise.
	 */
	public boolean equals(Object aObject) {
		if (!(aObject instanceof EPPChangeExt)) { return false; }
		EPPChangeExt other = (EPPChangeExt) aObject;
		return EqualityUtil.equals(this.requestId, other.requestId);
	}

}
