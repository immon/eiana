/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change.type;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.verisign.epp.codec.change.EPPChangeCreateCmd;
import com.verisign.epp.codec.change.EPPChangeInfoResp;
import com.verisign.epp.codec.change.util.TextUtil;
import com.verisign.epp.util.EqualityUtil;

/**
 * This is a convenience class to logically encapsulate a Change Request. This
 * class does not represent an EPPComponent because there is no change:request
 * tag specified in the schema. This class is very similar to the
 * EPPChangeInfoResp class except that the Response object represents a natural
 * EPPComponent.
 * @author jcolosi
 */
public class EPPChangeRequest {

	private String requestId = null;
	private String priority = null;
	private List categories = null;
	private String description = null;
	private String status = null;
	private Date createdDate = null;
	private Date updatedDate = null;
	private String createdId = null;
	private String updatedId = null;
	private ArrayList actions = null;

	public EPPChangeRequest(EPPChangeCreateCmd cmd) {
		setRequestId(cmd.getRequestId());
		setPriority(cmd.getPriority());
		setCategories(cmd.getCategories());
		setDescription(cmd.getDescription());
	}

	public void addAction(EPPChangeAction action) {
		if (actions == null) actions = new ArrayList();
		if (action != null) actions.add(action);
	}

	public void addCategory(String category) {
		if (categories == null) categories = new ArrayList();
		if (category != null) categories.add(TextUtil.normalize(category));
	}

	public void clearActions() {
		this.actions = null;
	}

	public void clearCategories() {
		this.categories = null;
	}

	/**
	 * Compare an instance of <code>EPPChangeInfoResp</code> with this
	 * instance
	 */
	public boolean equals(Object o) {
		if ((o == null) || (!o.getClass().equals(this.getClass()))) return false;
		EPPChangeRequest other = (EPPChangeRequest) o;

		return EqualityUtil.equals(this.requestId, other.requestId)
				&& EqualityUtil.equals(this.priority, other.priority)
				&& EqualityUtil.equals(this.categories, other.categories)
				&& EqualityUtil.equals(this.requestId, other.requestId)
				&& EqualityUtil.equals(this.description, other.description)
				&& EqualityUtil.equals(this.status, other.status)
				&& EqualityUtil.equals(this.createdDate, other.createdDate)
				&& EqualityUtil.equals(this.updatedDate, other.updatedDate)
				&& EqualityUtil.equals(this.createdId, other.createdId)
				&& EqualityUtil.equals(this.updatedId, other.updatedId)
				&& EqualityUtil.equals(this.actions, other.actions);
	}

	public ArrayList getActions() {
		return actions;
	}

	public List getCategories() {
		return categories;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public String getCreatedDateString() {
		return TextUtil.encodeDate(createdDate);
	}

	public String getCreatedId() {
		return createdId;
	}

	public String getDescription() {
		return description;
	}

	public EPPChangeInfoResp getInfoResponse() {
		EPPChangeInfoResp response = new EPPChangeInfoResp();
		response.setRequestId(getRequestId());
		response.setPriority(getPriority());
		response.setCategories(getCategories());
		response.setDescription(getDescription());
		response.setStatus(getStatus());
		response.setCreatedDate(getCreatedDate());
		response.setUpdatedDate(getUpdatedDate());
		response.setCreatedId(getCreatedId());
		response.setUpdatedId(getUpdatedId());
		response.setActions(getActions());
		return response;
	}

	public String getPriority() {
		return priority;
	}

	public String getRequestId() {
		return requestId;
	}

	public String getStatus() {
		return status;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public String getUpdatedDateString() {
		return TextUtil.encodeDate(updatedDate);
	}

	public String getUpdatedId() {
		return updatedId;
	}

	public void setActions(ArrayList actions) {
		this.actions = actions;
	}

	public void setCategories(List categories) {
		this.categories = categories;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = TextUtil.normalize(createdDate);
	}

	public void setCreatedDate(String createdDate) throws ParseException {
		this.createdDate = TextUtil.decodeDate(createdDate);
	}

	public void setCreatedId(String createdId) {
		this.createdId = TextUtil.normalize(createdId);
	}

	public void setDescription(String description) {
		this.description = TextUtil.normalize(description);
	}

	public void setPriority(String priority) {
		this.priority = TextUtil.normalize(priority);
	}

	public void setRequestId(String requestId) {
		this.requestId = TextUtil.normalize(requestId);
	}

	public void setStatus(String status) {
		this.status = TextUtil.normalize(status);
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = TextUtil.normalize(updatedDate);
	}

	public void setUpdatedDate(String updatedDate) throws ParseException {
		this.updatedDate = TextUtil.decodeDate(updatedDate);
	}

	public void setUpdatedId(String updatedId) {
		this.updatedId = TextUtil.normalize(updatedId);
	}

	public void updateAttributes(EPPChangeUpdateAttributes attrs) {
		setPriority(attrs.getPriority());
		setCategories(attrs.getCategories());
		setDescription(attrs.getDescription());
	}

}
