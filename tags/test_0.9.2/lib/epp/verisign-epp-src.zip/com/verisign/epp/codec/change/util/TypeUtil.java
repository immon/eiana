/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change.util;

public class TypeUtil {

	static public final String ELM_REQUESTID = "change:requestID";
	static public final String ELM_PRIORITY = "change:priority";
	static public final String ELM_CATEGORY = "change:category";
	static public final String ELM_DESCRIPTION = "change:desc";
	static public final String ELM_STATUS = "change:status";
	static public final String ELM_CREATED_DATE = "change:crDate";
	static public final String ELM_UPDATED_DATE = "change:upDate";
	static public final String ELM_CREATED_ID = "change:crID";
	static public final String ELM_UPDATED_ID = "change:upID";

	static public final String ELM_CLIENT_TRANS_ID = "change:cltrid";
	static public final String ELM_SERVER_TRANS_ID = "change:svtrid";
	static public final String ELM_DEFINITION = "change:def";

	static public final String ELM_SUBMIT = "change:submit";
	static public final String ELM_CLEAR = "change:clear";

	static public final String ELM_RECEIPT = "change:receipt";

	static public final String ATT_EXISTS = "exists";

}