/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.rootzone.interfaces;

import com.verisign.epp.codec.changeext.EPPChangeExt;
import com.verisign.epp.codec.gen.EPPResponse;
import com.verisign.epp.codec.idnext.EPPIdnLangTag;
import com.verisign.epp.interfaces.EPPCommandException;
import com.verisign.epp.interfaces.EPPDomain;
import com.verisign.epp.interfaces.EPPSession;

/**
 * NameStore Domain interface that extends that standard <code>EPPDomain</code>
 * by adding new operations like restore request, restore report, and sync.
 */
public class RZDomain extends EPPDomain {

	/**
	 * Creates an <code>NSDomain</code> with an established
	 * <code>EPPSession</code>.
	 * @param aSession Established session
	 */
	public RZDomain(EPPSession aSession) {
		super(aSession);
	}

	public EPPResponse sendCreate(String requestId) throws EPPCommandException {
		setRequestId(requestId);
		return super.sendCreate();
	}

	public EPPResponse sendDelete(String requestId) throws EPPCommandException {
		setRequestId(requestId);
		return super.sendDelete();
	}

	public EPPResponse sendUpdate(String requestId) throws EPPCommandException {
		setRequestId(requestId);
		return super.sendUpdate();
	}

	/**
	 * Set the IDN language tag used with <code>sendCreate</code>.
	 * @param aLangTag Valid XML schema language value as defined by <a
	 *            href="http://www.w3.org/TR/xmlschema-2/#language"/>. For
	 *            example, use a two letter language tag like <code>en</code>
	 *            or <code>fr</code>.
	 */
	public void setIDNLangTag(String aLangTag) {
		super.addExtension(new EPPIdnLangTag(aLangTag));
	}

	/**
	 * Add a Change Request to this Domain command. An Extension is created for
	 * the Change Request and applied to the EPPComponent.
	 * @param requestId
	 */
	public void setRequestId(String requestId) {
		super.addExtension(new EPPChangeExt(requestId));
	}

}
