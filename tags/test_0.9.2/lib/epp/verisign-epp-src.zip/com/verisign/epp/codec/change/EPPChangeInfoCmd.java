/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.verisign.epp.codec.change.util.ExceptionUtil;
import com.verisign.epp.codec.change.util.TextUtil;
import com.verisign.epp.codec.change.util.TypeUtil;
import com.verisign.epp.codec.gen.EPPCodec;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPInfoCmd;
import com.verisign.epp.codec.gen.EPPUtil;
import com.verisign.epp.util.EqualityUtil;

/**
 * Represents an EPP &lt;change:info&gt; command that is used to retrieve an EPP
 * Change Request object. The &lt;change:info&gt; element MUST contain the
 * following child elements: <br>
 * <br>
 * <ul>
 * <li>A &lt;change:requestID&gt; element that contains the Request Id. Use
 * <code>getRequestId</code> and <code>setRequestId</code> to get and set
 * the element.</li>
 * </ul>
 * <br>
 * <code>EPPChangeInfoResp</code> is the concrete <code>EPPReponse</code>
 * associated with <code>EPPChangeInfoCmd</code>.<br>
 * <br>
 * @see com.verisign.epp.codec.change.EPPChangeInfoResp
 * @author jcolosi
 */
public class EPPChangeInfoCmd extends EPPInfoCmd {
	static final String ELM_NAME = "change:info";

	private String requestId = null;

	public EPPChangeInfoCmd() {
		this(null);
	}

	public EPPChangeInfoCmd(String aTransId) {
		super(aTransId);
	}

	public EPPChangeInfoCmd(String aTransId, String requestId) {
		super(aTransId);
		setRequestId(requestId);
	}

	/**
	 * Clone <code>EPPChangeInfoCmd</code>.
	 * @return clone of <code>EPPChangeInfoCmd</code>
	 * @exception CloneNotSupportedException standard Object.clone exception
	 */
	public Object clone() throws CloneNotSupportedException {
		return (EPPChangeInfoCmd) super.clone();
	}

	/**
	 * Compare an instance of <code>EPPChangeInfoCmd</code> with this instance
	 */
	public boolean equals(Object o) {
		if ((o == null) || (!o.getClass().equals(this.getClass()))) return false;
		EPPChangeInfoCmd other = (EPPChangeInfoCmd) o;
		return EqualityUtil.equals(this.requestId, other.requestId);
	}

	/**
	 * Gets the EPP command Namespace associated with
	 * <code>EPPChangeInfoCmd</code>.
	 * @return <code>EPPChangeMapFactory.NS</code>
	 */
	public String getNamespace() {
		return EPPChangeMapFactory.NS;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = TextUtil.normalize(requestId);
	}

	/**
	 * Implementation of <code>Object.toString</code>, which will result in
	 * an indented XML <code>String</code> representation of the concrete
	 * <code>EPPCodecComponent</code>.
	 * @return Indented XML <code>String</code> if successful;
	 *         <code>ERROR</code> otherwise.
	 */
	public String toString() {
		return EPPUtil.toString(this);
	}

	/**
	 * Decode the <code>EPPChangeInfoCmd</code> attributes from the aElement
	 * DOM Element tree.
	 * @param aElement Root DOM Element to decode <code>EPPChangeInfoCmd</code>
	 *            from.
	 * @exception EPPDecodeException Unable to decode aElement
	 */
	protected void doDecode(Element aElement) throws EPPDecodeException {
		/**
		 * LOGIC: Decode nested elements
		 */
		NodeList nodes = aElement.getChildNodes();
		if (nodes != null) {
			int size = nodes.getLength();
			for (int i = 0; i < size; i++) {
				Node node = nodes.item(i);
				if (node instanceof Element) {
					String name = node.getNodeName();
					if (name.equals(TypeUtil.ELM_REQUESTID)) {
						setRequestId(EPPUtil.getTextContent(node));
					}
				}
			}
		}

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForDecode(requestId, TypeUtil.ELM_REQUESTID);
	}

	/**
	 * Encode a DOM Element tree from the attributes of the
	 * <code>EPPChangeInfoCmd</code> instance.
	 * @param aDocument DOM Document that is being built. Used as an Element
	 *            factory.
	 * @return Root DOM Element representing the <code>EPPChangeInfoCmd</code>
	 *         instance.
	 * @exception EPPEncodeException Unable to encode
	 *                <code>EPPChangeInfoCmd</code> instance.
	 */
	protected Element doEncode(Document aDocument) throws EPPEncodeException {
		Element root = aDocument.createElementNS(EPPChangeMapFactory.NS, ELM_NAME);
		root.setAttribute("xmlns:change", EPPChangeMapFactory.NS);
		root.setAttributeNS(EPPCodec.NS_XSI, "xsi:schemaLocation",
				EPPChangeMapFactory.NS_SCHEMA);

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForEncode(requestId, TypeUtil.ELM_REQUESTID);

		EPPUtil.encodeString(aDocument, root, requestId, EPPChangeMapFactory.NS,
				TypeUtil.ELM_REQUESTID);

		return root;
	}
}