/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change;

import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.verisign.epp.codec.change.type.EPPChangeCheckData;
import com.verisign.epp.codec.change.util.ExceptionUtil;
import com.verisign.epp.codec.gen.EPPCodec;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPResponse;
import com.verisign.epp.codec.gen.EPPTransId;
import com.verisign.epp.codec.gen.EPPUtil;
import com.verisign.epp.util.EqualityUtil;

/**
 * An <code>EPPChangeCheckResp</code> provides an answer to an
 * <code>EPPChangeCheckCmd</code> and includes the following attributes:<br>
 * <br>
 * <ul>
 * <li>1 or more &lt;change:cd&gt; elements that represent EPPChangeCheckData.
 * Each &lt;change:cd&gt; contains the <code>change:requestID</code> as well
 * as an <code>exists</code> attribute describing whether the Change Request
 * was found on the server. Use addCheckData, clearCheckData, getCheckData, and
 * setCheckData to manipulate the CheckData assoicated with this Check Response.</li>
 * </ul>
 * <br>
 * @see EPPChangeCheckCmd
 * @author jcolosi
 */
public class EPPChangeCheckResp extends EPPResponse {
	final static String ELM_NAME = "change:chkData";

	private ArrayList checkData = null;

	public EPPChangeCheckResp() {}

	/**
	 * Creates an <code>EPPChangeCheckResp</code> setting the transaction id.
	 * @param aTransId The transaction id containing the server transaction and
	 *            optionally the client transaction id
	 */
	public EPPChangeCheckResp(EPPTransId aTransId) {
		super(aTransId);
	}

	public EPPChangeCheckResp(EPPTransId aTransId, EPPChangeCheckData datum) {
		super(aTransId);
		addCheckData(datum);
	}

	public void addCheckData(EPPChangeCheckData datum) {
		if (checkData == null) checkData = new ArrayList();
		if (datum != null) checkData.add(datum);
	}

	public void clearCheckData() {
		this.checkData = null;
	}

	/**
	 * Does a deep clone of the <code>EPPChangeCheckResp</code> instance.
	 * @return Cloned instance
	 */
	public Object clone() throws CloneNotSupportedException {
		return (EPPChangeCheckResp) super.clone();
	}

	/**
	 * Compare an instance of <code>EPPChangeCheckResp</code> with this
	 * instance
	 */
	public boolean equals(Object o) {
		if ((o == null) || (!o.getClass().equals(this.getClass()))) return false;
		EPPChangeCheckResp other = (EPPChangeCheckResp) o;
		return EqualityUtil.equals(this.checkData, other.checkData);
	}

	public ArrayList getCheckData() {
		return checkData;
	}

	/**
	 * Gets the EPP command namespace associated with
	 * <code>EPPChangeCheckResp</code>.
	 * @return <code>EPPChangeMapFactory.NS</code>
	 */
	public String getNamespace() {
		return EPPChangeMapFactory.NS;
	}

	/**
	 * Gets the EPP response type associated with
	 * <code>EPPChangeCheckResp</code>.
	 * @return <code>EPPChangeCheckResp.ELM_NAME</code>
	 */
	public String getType() {
		return ELM_NAME;
	}

	public void setCheckData(ArrayList checkData) {
		this.checkData = checkData;
	}

	/**
	 * Implementation of <code>Object.toString</code>, which will result in
	 * an indented XML <code>String</code> representation of the concrete
	 * <code>EPPCodecComponent</code>.
	 * @return Indented XML <code>String</code> if successful;
	 *         <code>ERROR</code> otherwise.
	 */
	public String toString() {
		return EPPUtil.toString(this);
	}

	/**
	 * Decode the <code>EPPChangeCheckResp</code> attributes from the aElement
	 * DOM Element tree.
	 * @param aElement Root DOM Element to decode
	 *            <code>EPPChangeCheckResp</code> from.
	 * @exception EPPDecodeException Unable to decode aElement
	 */
	protected void doDecode(Element aElement) throws EPPDecodeException {
		/**
		 * LOGIC: Decode nested change:cd elements
		 */
		NodeList nodes = aElement.getChildNodes();
		if (nodes != null) {
			int size = nodes.getLength();
			for (int i = 0; i < size; i++) {
				Node node = nodes.item(i);
				if (node instanceof Element) {
					String name = node.getNodeName();
					if (name.equals(EPPChangeCheckData.ELM_NAME)) {
						addCheckData(new EPPChangeCheckData((Element) node));
					}
				}
			}
		}

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForDecode(checkData, EPPChangeCheckData.ELM_NAME);
	}

	/**
	 * Encode a DOM Element tree from the attributes of the
	 * <code>EPPChangeCheckResp</code> instance.
	 * @param aDocument DOM Document that is being built. Used as an Element
	 *            factory.
	 * @return Root DOM Element representing the <code>EPPChangeCheckResp</code>
	 *         instance.
	 * @exception EPPEncodeException Unable to encode
	 *                <code>EPPChangeCheckResp</code> instance.
	 */
	protected Element doEncode(Document aDocument) throws EPPEncodeException {
		Element root = aDocument.createElementNS(EPPChangeMapFactory.NS, ELM_NAME);
		root.setAttribute("xmlns:change", EPPChangeMapFactory.NS);
		root.setAttributeNS(EPPCodec.NS_XSI, "xsi:schemaLocation",
				EPPChangeMapFactory.NS_SCHEMA);

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForEncode(checkData, EPPChangeCheckData.ELM_NAME);

		EPPUtil.encodeCompList(aDocument, root, checkData);

		return root;
	}

}
