/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.verisign.epp.codec.change.util.TypeUtil;
import com.verisign.epp.codec.gen.EPPCodec;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPResponse;
import com.verisign.epp.codec.gen.EPPTransId;
import com.verisign.epp.codec.gen.EPPUtil;
import com.verisign.epp.util.EqualityUtil;

/**
 * An <code>EPPChangeUpdateResp</code> provides an answer to an
 * <code>EPPChangeUpdateCmd</code> and includes the following attributes:<br>
 * <br>
 * <ul>
 * <li>A &lt;change:receipt&gt; element that contains the Submission Receipt.
 * Use <code>getReceipt</code> and <code>setReceipt</code> to get and set
 * the element.</li>
 * </ul>
 * <br>
 * @see EPPChangeInfoCmd
 * @author jcolosi
 */
public class EPPChangeUpdateResp extends EPPResponse {
	final static String ELM_NAME = "change:updData";

	private String receipt = null;

	/**
	 * Default constructor that needs the <code>key</code> attribute and the
	 * transid attribute set prior to calling <code>encode</code>.
	 */
	public EPPChangeUpdateResp() {}

	/**
	 * Creates an <code>EPPChangeInfoResp</code> only the transaction id set.
	 * The <code>key</code> attribute must be set prior to calling
	 * <code>encode</code>.
	 * @param aTransId The transaction id containing the server transaction and
	 *            optionally the client transaction id
	 */
	public EPPChangeUpdateResp(EPPTransId aTransId) {
		super(aTransId);
	}

	/**
	 * Does a deep clone of the <code>EPPChangeInfoResp</code> instance.
	 * @return Cloned instance
	 */
	public Object clone() throws CloneNotSupportedException {
		return (EPPChangeUpdateResp) super.clone();
	}

	/**
	 * Compare an instance of <code>EPPChangeInfoResp</code> with this
	 * instance
	 */
	public boolean equals(Object o) {
		if ((o == null) || (!o.getClass().equals(this.getClass()))) return false;
		EPPChangeUpdateResp other = (EPPChangeUpdateResp) o;

		return EqualityUtil.equals(this.receipt, other.receipt);
	}

	/**
	 * Gets the EPP command namespace associated with
	 * <code>EPPChangeInfoResp</code>.
	 * @return <code>EPPChangeMapFactory.NS</code>
	 */
	public String getNamespace() {
		return EPPChangeMapFactory.NS;
	}

	public String getReceipt() {
		return receipt;
	}

	/**
	 * Gets the EPP response type associated with <code>EPPChangeInfoResp</code>.
	 * @return <code>EPPChangeInfoResp.ELM_NAME</code>
	 */
	public String getType() {
		return ELM_NAME;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	/**
	 * Implementation of <code>Object.toString</code>, which will result in
	 * an indented XML <code>String</code> representation of the concrete
	 * <code>EPPCodecComponent</code>.
	 * @return Indented XML <code>String</code> if successful;
	 *         <code>ERROR</code> otherwise.
	 */
	public String toString() {
		return EPPUtil.toString(this);
	}

	/**
	 * Decode the <code>EPPChangeInfoResp</code> attributes from the aElement
	 * DOM Element tree.
	 * @param aElement Root DOM Element to decode <code>EPPChangeInfoResp</code>
	 *            from.
	 * @exception EPPDecodeException Unable to decode aElement
	 */
	protected void doDecode(Element aElement) throws EPPDecodeException {
		/**
		 * LOGIC: Decode nested elements
		 */
		NodeList nodes = aElement.getChildNodes();
		if (nodes != null) {
			int size = nodes.getLength();
			for (int i = 0; i < size; i++) {
				Node node = nodes.item(i);
				if (node instanceof Element) {
					String name = node.getNodeName();
					if (name.equals(TypeUtil.ELM_RECEIPT)) setReceipt(EPPUtil
							.getTextContent(node));
				}
			}
		}

		/**
		 * LOGIC: Receipt is not required because clear and updateAttrs will not
		 * have a receipt. Do not assert anything below.
		 */
		// ExceptionUtil.assertForDecode(recipt, TypeUtil.ELM_RECEIPT);
	}

	/**
	 * Encode a DOM Element tree from the attributes of the
	 * <code>EPPChangeInfoResp</code> instance.
	 * @param aDocument DOM Document that is being built. Used as an Element
	 *            factory.
	 * @return Root DOM Element representing the <code>EPPChangeInfoResp</code>
	 *         instance.
	 * @exception EPPEncodeException Unable to encode
	 *                <code>EPPChangeInfoResp</code> instance.
	 */
	protected Element doEncode(Document aDocument) throws EPPEncodeException {
		Element root = aDocument.createElementNS(EPPChangeMapFactory.NS, ELM_NAME);
		root.setAttribute("xmlns:change", EPPChangeMapFactory.NS);
		root.setAttributeNS(EPPCodec.NS_XSI, "xsi:schemaLocation",
				EPPChangeMapFactory.NS_SCHEMA);

		/**
		 * LOGIC: Receipt is not required because clear and updateAttrs will not
		 * have a receipt. Do not assert anything below.
		 */
		// ExceptionUtil.assertForEncode(receipt, TypeUtil.ELM_RECEIPT);
		EPPUtil.encodeString(aDocument, root, receipt, EPPChangeMapFactory.NS,
				TypeUtil.ELM_RECEIPT);

		return root;
	}

}
