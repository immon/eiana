/***********************************************************
Copyright (C) 2004 VeriSign, Inc.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA� 02111-1307� USA

http://www.verisign.com/nds/naming/namestore/techdocs.html
***********************************************************/
package com.verisign.epp.util;

import com.verisign.epp.util.EPPEnv;


/**
 * This is a Singleton Class Please See Singleton Design Pattern
 *
 * @author P. Amiri
 * @version $Id: EPPEnvSingle.java,v 1.3 2004/01/26 21:21:07 jim Exp $
 *
 * @since JDK1.0
 */
public class EPPEnvSingle extends EPPEnv {
	/** DOCUMENT ME! */
	private static EPPEnvSingle myInstance = null;

	/**
	 * DOCUMENT ME!
	 *
	 * @since JDK1.1 Private constructor supresses public instantiation
	 */
	private EPPEnvSingle() {
	}

	/**
	 * DOCUMENT ME!
	 *
	 * @return an instance of EPPEnvSingle
	 */
	public static EPPEnvSingle getInstance() {
		if (myInstance == null) {
			myInstance = new EPPEnvSingle();
		}

		return myInstance;
	}
}
