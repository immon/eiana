/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.codec.change;

import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.verisign.epp.codec.change.util.ExceptionUtil;
import com.verisign.epp.codec.change.util.TypeUtil;
import com.verisign.epp.codec.gen.EPPCheckCmd;
import com.verisign.epp.codec.gen.EPPCodec;
import com.verisign.epp.codec.gen.EPPDecodeException;
import com.verisign.epp.codec.gen.EPPEncodeException;
import com.verisign.epp.codec.gen.EPPUtil;
import com.verisign.epp.util.EqualityUtil;

/**
 * Represents an EPP &lt;change:check&gt; command that is used to determine the
 * existence of an EPP Change Request object. The &lt;change:check&gt; element
 * MUST contain the following child elements: <br>
 * <br>
 * <ul>
 * <li>A &lt;change:requestID&gt; element that contains the Request Id. Use
 * <code>getRequestId</code> and <code>setRequestId</code> to get and set
 * the element.</li>
 * </ul>
 * <br>
 * <code>EPPChangeCheckResp</code> is the concrete <code>EPPReponse</code>
 * associated with <code>EPPChangecheckCmd</code>.<br>
 * <br>
 * @see com.verisign.epp.codec.change.EPPChangeCheckResp
 * @author jcolosi
 */
public class EPPChangeCheckCmd extends EPPCheckCmd {

	static final String ELM_NAME = "change:check";

	private ArrayList requestIds = null;

	public EPPChangeCheckCmd() {
		this(null);
	}

	public EPPChangeCheckCmd(String aTransId) {
		super(aTransId);
	}

	public EPPChangeCheckCmd(String aTransId, String requestId) {
		super(aTransId);
		addRequestId(requestId);
	}

	public void addRequestId(String requestId) {
		if (requestIds == null) requestIds = new ArrayList();
		if (requestId != null) requestIds.add(requestId);
	}

	public void clearRequestIds() {
		this.requestIds = null;
	}

	/**
	 * Clone <code>EPPChangeCheckCmd</code>.
	 * @return clone of <code>EPPChangeCheckCmd</code>
	 * @exception CloneNotSupportedException standard Object.clone exception
	 */
	public Object clone() throws CloneNotSupportedException {
		return (EPPChangeCheckCmd) super.clone();
	}

	/**
	 * Compare an instance of <code>EPPChangeCheckCmd</code> with this
	 * instance
	 */
	public boolean equals(Object o) {
		if ((o == null) || (!o.getClass().equals(this.getClass()))) return false;
		EPPChangeCheckCmd other = (EPPChangeCheckCmd) o;
		return EqualityUtil.equals(this.requestIds, other.requestIds);
	}

	/**
	 * Gets the EPP command Namespace associated with
	 * <code>EPPChangeCheckCmd</code>.
	 * @return <code>EPPChangeMapFactory.NS</code>
	 */
	public String getNamespace() {
		return EPPChangeMapFactory.NS;
	}

	public ArrayList getRequestIds() {
		return requestIds;
	}

	public void setRequestIds(ArrayList requestIds) {
		this.requestIds = requestIds;
	}

	/**
	 * Implementation of <code>Object.toString</code>, which will result in
	 * an indented XML <code>String</code> representation of the concrete
	 * <code>EPPCodecComponent</code>.
	 * @return Indented XML <code>String</code> if successful;
	 *         <code>ERROR</code> otherwise.
	 */
	public String toString() {
		return EPPUtil.toString(this);
	}

	/**
	 * Decode the <code>EPPChangeCheckCmd</code> attributes from the aElement
	 * DOM Element tree.
	 * @param aElement Root DOM Element to decode <code>EPPChangeCheckCmd</code>
	 *            from.
	 * @exception EPPDecodeException Unable to decode aElement
	 */
	protected void doDecode(Element aElement) throws EPPDecodeException {
		/**
		 * LOGIC: Decode nested Change:Request elements
		 */
		NodeList nodes = aElement.getChildNodes();
		if (nodes != null) {
			int size = nodes.getLength();
			for (int i = 0; i < size; i++) {
				Node node = nodes.item(i);
				if (node instanceof Element) {
					String name = node.getNodeName();
					if (name.equals(TypeUtil.ELM_REQUESTID)) {
						addRequestId(EPPUtil.getTextContent(node));
					}
				}
			}
		}

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForDecode(requestIds, TypeUtil.ELM_REQUESTID);
	}

	/**
	 * Encode a DOM Element tree from the attributes of the
	 * <code>EPPChangeCheckCmd</code> instance.
	 * @param aDocument DOM Document that is being built. Used as an Element
	 *            factory.
	 * @return Root DOM Element representing the <code>EPPChangeCheckCmd</code>
	 *         instance.
	 * @exception EPPEncodeException Unable to encode
	 *                <code>EPPChangeCheckCmd</code> instance.
	 */
	protected Element doEncode(Document aDocument) throws EPPEncodeException {
		Element root = aDocument.createElementNS(EPPChangeMapFactory.NS, ELM_NAME);
		root.setAttribute("xmlns:change", EPPChangeMapFactory.NS);
		root.setAttributeNS(EPPCodec.NS_XSI, "xsi:schemaLocation",
				EPPChangeMapFactory.NS_SCHEMA);

		/**
		 * LOGIC: Assert required params
		 */
		ExceptionUtil.assertForEncode(requestIds, TypeUtil.ELM_REQUESTID);

		EPPUtil.encodeStringList(aDocument, root, requestIds, EPPChangeMapFactory.NS,
				TypeUtil.ELM_REQUESTID);

		return root;
	}
}