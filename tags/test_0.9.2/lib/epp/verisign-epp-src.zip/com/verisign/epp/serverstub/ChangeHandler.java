/***********************************************************
 Copyright (C) 2004 VeriSign, Inc.

 This library is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 2.1 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-0107  USA

 http://www.verisign.com/nds/naming/namestore/techdocs.html
 ***********************************************************/
package com.verisign.epp.serverstub;

import com.verisign.epp.codec.change.EPPChangeCheckCmd;
import com.verisign.epp.codec.change.EPPChangeCheckResp;
import com.verisign.epp.codec.change.EPPChangeCreateCmd;
import com.verisign.epp.codec.change.EPPChangeDeleteCmd;
import com.verisign.epp.codec.change.EPPChangeInfoCmd;
import com.verisign.epp.codec.change.EPPChangeInfoResp;
import com.verisign.epp.codec.change.EPPChangeUpdateCmd;
import com.verisign.epp.codec.change.EPPChangeUpdateResp;
import com.verisign.epp.codec.change.util.RandomHelper;
import com.verisign.epp.codec.gen.EPPCommand;
import com.verisign.epp.codec.gen.EPPResponse;
import com.verisign.epp.codec.gen.EPPResult;
import com.verisign.epp.codec.gen.EPPTransId;
import com.verisign.epp.framework.EPPChangeHandler;
import com.verisign.epp.framework.EPPEvent;
import com.verisign.epp.framework.EPPEventResponse;
import com.verisign.epp.framework.EPPHandleEventException;

public class ChangeHandler extends EPPChangeHandler {

	/**
	 * The server transaction id used for all responses
	 */
	private static final String svrTransId = "SRV-thx1138";

	/**
	 * Constructs an instance of ChangeHandler
	 */
	public ChangeHandler() {}

	/**
	 * Handles any common behavior that all Change commands need to execute
	 * before they execute their command specific behavior.
	 * @param aEvent The <code>EPPEvent</code> that is being handled
	 * @param aData Any data that a Server needs to send to this
	 *            <code>EPPChangeHandler</code> This is assumed to be an
	 *            instance of SessionData here.
	 * @exception EPPHandleEventException Thrown if an error condition occurs.
	 *                It must contain an <code>EPPEventResponse</code>
	 */
	protected void preHandleEvent(EPPEvent aEvent, Object aData)
			throws EPPHandleEventException {
		SessionData sessionData = (SessionData) aData;
		EPPCommand theMessage = (EPPCommand) aEvent.getMessage();

		if (!sessionData.isLoggedIn()) {
			/**
			 * Create the transId for the response with the client trans id and
			 * the server trans id.
			 */
			EPPTransId transId = new EPPTransId(theMessage.getTransId(), svrTransId);

			// Create the Response (Standard EPPResponse)
			EPPResponse theResponse = new EPPResponse(transId);

			theResponse.setResult(EPPResult.COMMAND_USE_ERROR);
			throw new EPPHandleEventException(
					"The client has not established a session", theResponse);
		}
	}

	/**
	 * Handles any common behavior that all Change commands need to execute
	 * after they execute their command specific behavior.
	 * @param aEvent The <code>EPPEvent</code> that is being handled
	 * @param aData Any data that a Server needs to send to this
	 *            <code>EPPChangeHandler</code>
	 * @exception EPPHandleEventException Thrown if an error condition occurs.
	 *                It must contain an <code>EPPEventResponse</code>
	 */
	protected void postHandleEvent(EPPEvent aEvent, Object aData)
			throws EPPHandleEventException {}

	/**
	 * Invoked when a Change Info command is received.
	 * @param aEvent The <code>EPPEvent</code> that is being handled
	 * @param aData Any data that a Server needs to send to this
	 *            <code>EPPChangedHandler</code>
	 * @return EPPEventResponse The response that should be sent back to the
	 *         client.
	 */

	protected EPPEventResponse doChangeCheck(EPPEvent aEvent, Object aData) {
		EPPChangeCheckCmd cmd = (EPPChangeCheckCmd) aEvent.getMessage();
		String cltrid = cmd.getTransId();

		EPPChangeCheckResp resp = RandomHelper.getChangeCheckResp(cltrid);
		resp.setResult(EPPResult.SUCCESS);

		return new EPPEventResponse(resp);
	}

	protected EPPEventResponse doChangeInfo(EPPEvent aEvent, Object aData) {
		EPPChangeInfoCmd cmd = (EPPChangeInfoCmd) aEvent.getMessage();
		String cltrid = cmd.getTransId();

		EPPChangeInfoResp resp = RandomHelper.getChangeInfoResp(cltrid);
		resp.setResult(EPPResult.SUCCESS);

		return new EPPEventResponse(resp);
	}

	protected EPPEventResponse doChangeCreate(EPPEvent aEvent, Object aData) {
		EPPChangeCreateCmd cmd = (EPPChangeCreateCmd) aEvent.getMessage();
		String cltrid = cmd.getTransId();

		EPPResponse resp = RandomHelper.getEppResponse(cltrid);
		resp.setResult(EPPResult.SUCCESS);

		return new EPPEventResponse(resp);
	}

	protected EPPEventResponse doChangeUpdate(EPPEvent aEvent, Object aData) {
		EPPChangeUpdateCmd cmd = (EPPChangeUpdateCmd) aEvent.getMessage();
		String cltrid = cmd.getTransId();

		EPPChangeUpdateResp resp = RandomHelper.getChangeUpdateResp(cltrid);
		resp.setResult(EPPResult.SUCCESS);

		return new EPPEventResponse(resp);
	}

	protected EPPEventResponse doChangeDelete(EPPEvent aEvent, Object aData) {
		EPPChangeDeleteCmd cmd = (EPPChangeDeleteCmd) aEvent.getMessage();
		String cltrid = cmd.getTransId();

		EPPResponse resp = RandomHelper.getEppResponse(cltrid);
		resp.setResult(EPPResult.SUCCESS);

		return new EPPEventResponse(resp);
	}
}
